#!/usr/bin/env python3
"""Генератор scenes/Player.tscn (v9): игрок + HandRig (женские руки в льняных рукавах) + факел.

Руки собираются из низкополигональных примитивов (капсулы/сферы/цилиндры) — внешних моделей не нужно.
Запуск из корня проекта:  python3 tools/build_player_scene.py
"""
import math
import os

# ------------------------------------------------------------------ математика
def add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])
def sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def mul(a, k): return (a[0] * k, a[1] * k, a[2] * k)
def dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
def length(a): return math.sqrt(dot(a, a))
def norm(a):
    l = length(a)
    return (a[0] / l, a[1] / l, a[2] / l)

def mat_mul(A, B):  # матрицы 3x3 по строкам
    return [[sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def rot_x(t):
    c, s = math.cos(t), math.sin(t)
    return [[1, 0, 0], [0, c, -s], [0, s, c]]
def rot_z(t):
    c, s = math.cos(t), math.sin(t)
    return [[c, -s, 0], [s, c, 0], [0, 0, 1]]
def mat_vec(M, v):
    return tuple(sum(M[i][k] * v[k] for k in range(3)) for i in range(3))
def col(M, j):
    return (M[0][j], M[1][j], M[2][j])

def f(x):
    s = ("%.5f" % x).rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s

def tf(origin, ax, ay, az):
    """Transform3D(...) — Godot пишет базис по строкам."""
    return "Transform3D(%s)" % ", ".join(
        f(v) for v in (ax[0], ay[0], az[0], ax[1], ay[1], az[1], ax[2], ay[2], az[2], origin[0], origin[1], origin[2]))

def basis_from_y(ydir, zhint=(0.0, 0.0, 1.0)):
    y = norm(ydir)
    x = norm(cross(y, zhint))
    z = cross(x, y)
    return x, y, z

# ------------------------------------------------------------------ ресурсы
subres = []   # (id, text)
_cache = {}

def res(kind, rid, body):
    key = (kind, body)
    if key in _cache:
        return _cache[key]
    sid = "%s_%s" % (rid, len([1 for k in _cache if k[0] == kind]))
    subres.append('[sub_resource type="%s" id="%s"]\n%s\n' % (kind, sid, body))
    _cache[key] = sid
    return sid

def mat_std(name, body):
    return res("StandardMaterial3D", name, body)

SKIN = mat_std("mat_skin",
    "albedo_color = Color(0.95, 0.80, 0.71, 1)\nroughness = 0.78\nmetallic_specular = 0.3\n"
    "rim_enabled = true\nrim = 0.22\nrim_tint = 0.65")
LINEN = mat_std("mat_linen",
    "albedo_color = Color(0.90, 0.88, 0.80, 1)\nroughness = 1.0\nmetallic_specular = 0.0")
CUFF = mat_std("mat_cuff",
    "albedo_color = Color(0.09, 0.14, 0.31, 1)\nroughness = 1.0\nmetallic_specular = 0.0")
EMBROIDERY = mat_std("mat_embroidery",
    "albedo_color = Color(0.62, 0.11, 0.09, 1)\nroughness = 1.0\nmetallic_specular = 0.0")
WOOD = mat_std("mat_torch_wood",
    "albedo_color = Color(0.42, 0.26, 0.14, 1)\nroughness = 0.95\nmetallic_specular = 0.1\n"
    "emission_enabled = true\nemission = Color(0.30, 0.14, 0.05, 1)\nemission_energy_multiplier = 0.5")
CHAR = mat_std("mat_torch_char",
    "albedo_color = Color(0.14, 0.08, 0.05, 1)\nroughness = 1.0\nmetallic_specular = 0.0\n"
    "emission_enabled = true\nemission = Color(0.35, 0.10, 0.03, 1)\nemission_energy_multiplier = 0.6")
ROPE = mat_std("mat_torch_rope",
    "albedo_color = Color(0.5, 0.38, 0.22, 1)\nroughness = 1.0\nmetallic_specular = 0.0")
EMBER = mat_std("mat_torch_ember",
    "albedo_color = Color(0.25, 0.06, 0.02, 1)\nroughness = 1.0\nemission_enabled = true\n"
    "emission = Color(1, 0.42, 0.08, 1)\nemission_energy_multiplier = 3.2")

nodes = []  # (name, type, parent, props: list[str])

def node(name, ntype, parent, props=None, extra=""):
    nodes.append((name, ntype, parent, props or [], extra))

_names = {}
def uname(parent, base):
    k = (parent, base)
    _names[k] = _names.get(k, 0) + 1
    return base if _names[k] == 1 else "%s%d" % (base, _names[k])

def mesh_node(parent, base, mesh_id, mat_id, xform=None):
    props = ["transform = %s" % xform] if xform else []
    props += ['mesh = SubResource("%s")' % mesh_id,
              "cast_shadow = 0",
              'surface_material_override/0 = SubResource("%s")' % mat_id]
    node(uname(parent, base), "MeshInstance3D", parent, props)

def capsule_mesh(r, h):
    return res("CapsuleMesh", "cap", "radius = %s\nheight = %s\nradial_segments = 8\nrings = 3" % (f(r), f(h)))

def cyl_mesh(rt, rb, h, seg=10):
    return res("CylinderMesh", "cyl",
               "top_radius = %s\nbottom_radius = %s\nheight = %s\nradial_segments = %d\nrings = 1"
               % (f(rt), f(rb), f(h), seg))

def sph_mesh():
    return res("SphereMesh", "sph", "radius = 1.0\nheight = 2.0\nradial_segments = 12\nrings = 6")

def limb(parent, base, a, b, r, mat):
    """Капсула между точками a и b (в координатах родителя)."""
    d = sub(b, a)
    l = length(d)
    ax, ay, az = basis_from_y(d, (0.0, 0.0, 1.0) if abs(norm(d)[2]) < 0.9 else (1.0, 0.0, 0.0))
    mid = mul(add(a, b), 0.5)
    mesh_node(parent, base, capsule_mesh(r, l + 2 * r), mat, tf(mid, ax, ay, az))

def ellipsoid(parent, base, c, axes, semi, mat):
    """axes — три единичных вектора (x,y,z), semi — полуоси."""
    mesh_node(parent, base, sph_mesh(), mat,
              tf(c, mul(axes[0], semi[0]), mul(axes[1], semi[1]), mul(axes[2], semi[2])))

def polyline(parent, base, pts, r, mat):
    for i in range(len(pts) - 1):
        limb(parent, "%s%d" % (base, i + 1), pts[i], pts[i + 1], r, mat)
    # шарики в суставах — гладкие стыки без швов
    for i in range(1, len(pts) - 1):
        ellipsoid(parent, "%sJoint%d" % (base, i), pts[i], ((1, 0, 0), (0, 1, 0), (0, 0, 1)), (r, r, r), mat)
    ellipsoid(parent, "%sTip" % base, pts[-1], ((1, 0, 0), (0, 1, 0), (0, 0, 1)), (r, r, r), mat)

def sleeve(parent, base, wrist, edir):
    """Рукав: кожа запястья -> тёмно-синяя манжета -> красная вышивка -> льняной рукав."""
    d = norm(edir)
    ax, ay, az = basis_from_y(d, (0.0, 0.0, 1.0))
    def at(t):
        return add(wrist, mul(d, t))
    limb(parent, base + "Forearm", at(-0.02), at(0.07), 0.025, SKIN)
    mesh_node(parent, base + "Cuff", cyl_mesh(0.039, 0.037, 0.05), CUFF, tf(at(0.06), ax, ay, az))
    mesh_node(parent, base + "Embroidery", cyl_mesh(0.0405, 0.0405, 0.011), EMBROIDERY, tf(at(0.092), ax, ay, az))
    mesh_node(parent, base + "Sleeve", cyl_mesh(0.064, 0.042, 0.36, 12), LINEN, tf(at(0.28), ax, ay, az))

# ------------------------------------------------------------------ геометрия
RIG = "Head/Camera3D/HandRig"
RIG_POS = (0.25, -0.35, -0.5)
G_R = (0.0, 0.10, 0.0)                                  # точка хвата правой руки (в HandRig)
TILT = mat_mul(rot_z(math.radians(10.0)), rot_x(math.radians(-24.0)))
TX, TY, TZ = col(TILT, 0), col(TILT, 1), col(TILT, 2)

def T(p):
    """Точка из локальных координат факела -> координаты HandRig."""
    return add(mat_vec(TILT, p), G_R)

def build_right_hand():
    P = RIG + "/RightArm"
    node("RightArm", "Node3D", RIG)
    # ладонь и тыльная сторона кисти — за рукоятью (+X)
    ellipsoid(P, "Palm", T((0.046, 0.0, 0.004)), (TX, TY, TZ), (0.021, 0.040, 0.040), SKIN)
    ellipsoid(P, "PalmHeel", T((0.050, -0.006, -0.026)), (TX, TY, TZ), (0.020, 0.032, 0.026), SKIN)
    # четыре пальца обхватывают рукоять спереди (+Z); индекс сверху
    ys = [0.033, 0.011, -0.011, -0.033]
    k = [1.0, 1.06, 1.0, 0.82]
    rr = [0.0105, 0.0108, 0.0105, 0.0094]
    for i, y in enumerate(ys):
        pts = [T((0.042, y, 0.022)), T((0.042 - 0.020 * k[i], y, 0.036)),
               T((0.042 - 0.046 * k[i], y, 0.032)), T((0.042 - 0.060 * k[i], y, 0.016))]
        polyline(P, "Finger%d" % (i + 1), pts, rr[i], SKIN)
    # большой палец лежит поверх указательного
    polyline(P, "Thumb", [T((0.046, 0.034, -0.012)), T((0.034, 0.050, 0.014)),
                         T((0.012, 0.052, 0.036)), T((-0.008, 0.048, 0.034))], 0.0115, SKIN)
    wrist = T((0.052, -0.004, -0.040))
    sleeve(P, "R", wrist, (0.30, -0.42, 0.85))

def build_left_hand():
    P = RIG + "/LeftArm"
    node("LeftArm", "Node3D", RIG)
    G = (-0.40, 0.05, 0.0)
    ax = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    ellipsoid(P, "Palm", add(G, (0.0, 0.0, -0.002)), ax, (0.017, 0.037, 0.040), SKIN)
    ys = [0.027, 0.009, -0.009, -0.027]
    k = [0.96, 1.0, 0.95, 0.78]
    rr = [0.0098, 0.0100, 0.0098, 0.0088]
    for i, y in enumerate(ys):
        kn = add(G, (0.0, y, -0.038))
        pts = [kn, add(kn, (0.002, 0.0, -0.034 * k[i])),
               add(kn, (0.010, 0.0, -0.062 * k[i])), add(kn, (0.022, 0.0, -0.082 * k[i]))]
        polyline(P, "Finger%d" % (i + 1), pts, rr[i], SKIN)
    polyline(P, "Thumb", [add(G, (0.004, 0.034, 0.000)), add(G, (0.012, 0.050, -0.022)),
                         add(G, (0.022, 0.056, -0.044)), add(G, (0.030, 0.056, -0.060))], 0.0112, SKIN)
    sleeve(P, "L", add(G, (0.0, -0.002, 0.044)), (-0.18, -0.40, 0.90))

def build_torch():
    P = RIG + "/Torch"
    node("Torch", "Node3D", RIG, ["transform = %s" % tf(G_R, TX, TY, TZ)])
    ident = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    mesh_node(P, "Handle", cyl_mesh(0.021, 0.016, 0.44), WOOD, tf((0, 0.12, 0), *ident))
    mesh_node(P, "Head", cyl_mesh(0.043, 0.027, 0.11), CHAR, tf((0, 0.345, 0), *ident))
    mesh_node(P, "BandLow", cyl_mesh(0.0325, 0.0325, 0.013), ROPE, tf((0, 0.305, 0), *ident))
    mesh_node(P, "BandHigh", cyl_mesh(0.0415, 0.0415, 0.013), ROPE, tf((0, 0.375, 0), *ident))
    mesh_node(P, "Ember", sph_mesh(), EMBER, tf((0, 0.405, 0), (0.037, 0, 0), (0, 0.032, 0), (0, 0, 0.037)))
    # свет: тёплый огонь #FFA036
    node("OmniLight3D", "OmniLight3D", P, [
        "transform = %s" % tf((0, 0.45, 0.13), *ident),
        "light_color = Color(1, 0.627451, 0.211765, 1)",
        "light_energy = 2.2",
        "light_specular = 0.6",
        "shadow_enabled = false",
        "omni_range = 14.0",
        "omni_attenuation = 1.2"])
    # ----- частицы
    g_flame = res("Gradient", "g_flame",
        "offsets = PackedFloat32Array(0, 0.2, 0.65, 1)\n"
        "colors = PackedColorArray(1, 0.95, 0.6, 0, 1, 0.85, 0.4, 1, 1, 0.4, 0.08, 0.85, 0.35, 0.06, 0, 0)")
    t_flame = res("GradientTexture1D", "t_flame", 'gradient = SubResource("%s")' % g_flame)
    c_flame = res("Curve", "c_flame",
        "_data = [Vector2(0, 0.7), 0.0, 0.0, 0, 0, Vector2(0.35, 1), 0.0, 0.0, 0, 0, Vector2(1, 0.15), 0.0, 0.0, 0, 0]\npoint_count = 3")
    ct_flame = res("CurveTexture", "ct_flame", 'curve = SubResource("%s")' % c_flame)
    pm_flame = res("ParticleProcessMaterial", "pm_flame",
        "emission_shape = 1\nemission_sphere_radius = 0.018\ndirection = Vector3(0, 1, 0)\nspread = 9.0\n"
        "initial_velocity_min = 0.25\ninitial_velocity_max = 0.5\ngravity = Vector3(0, 0.5, 0)\n"
        "scale_min = 0.7\nscale_max = 1.2\nscale_curve = SubResource(\"%s\")\n"
        "color_ramp = SubResource(\"%s\")\nanim_offset_min = 0.0\nanim_offset_max = 1.0" % (ct_flame, t_flame))
    m_flame = res("StandardMaterial3D", "m_flame",
        "transparency = 1\nblend_mode = 1\nshading_mode = 0\nvertex_color_use_as_albedo = true\n"
        "albedo_color = Color(1.9, 1.45, 1, 1)\nalbedo_texture = ExtResource(\"flame_tex\")\n"
        "disable_receive_shadows = true\nbillboard_mode = 3\nbillboard_keep_scale = true\n"
        "particles_anim_h_frames = 4\nparticles_anim_v_frames = 1\nparticles_anim_loop = false")
    q_flame = res("QuadMesh", "q_flame",
        'material = SubResource("%s")\nsize = Vector2(0.15, 0.27)\ncenter_offset = Vector3(0, 0.11, 0)' % m_flame)
    node("Flame", "GPUParticles3D", P, [
        "transform = %s" % tf((0, 0.40, 0), *ident), "amount = 20", "lifetime = 0.6", "preprocess = 0.6",
        "local_coords = false", "cast_shadow = 0",
        "visibility_aabb = AABB(-1, -1, -1, 2, 3, 2)",
        'process_material = SubResource("%s")' % pm_flame, 'draw_pass_1 = SubResource("%s")' % q_flame])

    g_soft = res("Gradient", "g_soft", "colors = PackedColorArray(1, 1, 1, 1, 1, 1, 1, 0)")
    t_soft = res("GradientTexture2D", "t_soft",
        'gradient = SubResource("%s")\nwidth = 64\nheight = 64\nfill = 1\nfill_from = Vector2(0.5, 0.5)\nfill_to = Vector2(1, 0.5)' % g_soft)
    # искры
    g_spark = res("Gradient", "g_spark",
        "offsets = PackedFloat32Array(0, 0.45, 1)\ncolors = PackedColorArray(1, 0.92, 0.55, 1, 1, 0.45, 0.08, 1, 0.5, 0.1, 0, 0)")
    tg_spark = res("GradientTexture1D", "tg_spark", 'gradient = SubResource("%s")' % g_spark)
    pm_spark = res("ParticleProcessMaterial", "pm_spark",
        "emission_shape = 1\nemission_sphere_radius = 0.025\ndirection = Vector3(0, 1, 0)\nspread = 32.0\n"
        "initial_velocity_min = 0.45\ninitial_velocity_max = 1.3\ngravity = Vector3(0, -0.25, 0)\n"
        "scale_min = 0.5\nscale_max = 1.3\ncolor_ramp = SubResource(\"%s\")" % tg_spark)
    m_spark = res("StandardMaterial3D", "m_spark",
        "transparency = 1\nblend_mode = 1\nshading_mode = 0\nvertex_color_use_as_albedo = true\n"
        'albedo_color = Color(3, 1.7, 0.6, 1)\nalbedo_texture = SubResource("%s")\n'
        "disable_receive_shadows = true\nbillboard_mode = 3\nbillboard_keep_scale = true" % t_soft)
    q_spark = res("QuadMesh", "q_spark", 'material = SubResource("%s")\nsize = Vector2(0.018, 0.018)' % m_spark)
    node("Sparks", "GPUParticles3D", P, [
        "transform = %s" % tf((0, 0.42, 0), *ident), "amount = 16", "lifetime = 0.95", "preprocess = 0.9",
        "randomness = 0.5", "local_coords = false", "cast_shadow = 0",
        "visibility_aabb = AABB(-1, -1, -1, 2, 3, 2)",
        'process_material = SubResource("%s")' % pm_spark, 'draw_pass_1 = SubResource("%s")' % q_spark])
    # лёгкий дым
    g_smoke = res("Gradient", "g_smoke",
        "offsets = PackedFloat32Array(0, 0.3, 1)\ncolors = PackedColorArray(0.26, 0.23, 0.2, 0, 0.28, 0.25, 0.22, 0.3, 0.15, 0.15, 0.15, 0)")
    tg_smoke = res("GradientTexture1D", "tg_smoke", 'gradient = SubResource("%s")' % g_smoke)
    c_smoke = res("Curve", "c_smoke",
        "_data = [Vector2(0, 0.5), 0.0, 0.0, 0, 0, Vector2(1, 2), 0.0, 0.0, 0, 0]\npoint_count = 2")
    ct_smoke = res("CurveTexture", "ct_smoke", 'curve = SubResource("%s")' % c_smoke)
    pm_smoke = res("ParticleProcessMaterial", "pm_smoke",
        "emission_shape = 1\nemission_sphere_radius = 0.02\ndirection = Vector3(0, 1, 0)\nspread = 14.0\n"
        "initial_velocity_min = 0.12\ninitial_velocity_max = 0.25\ngravity = Vector3(0, 0.3, 0)\n"
        "scale_min = 0.8\nscale_max = 1.3\nscale_curve = SubResource(\"%s\")\ncolor_ramp = SubResource(\"%s\")"
        % (ct_smoke, tg_smoke))
    m_smoke = res("StandardMaterial3D", "m_smoke",
        "transparency = 1\nshading_mode = 0\nvertex_color_use_as_albedo = true\n"
        'albedo_texture = SubResource("%s")\ndisable_receive_shadows = true\nbillboard_mode = 3\nbillboard_keep_scale = true' % t_soft)
    q_smoke = res("QuadMesh", "q_smoke", 'material = SubResource("%s")\nsize = Vector2(0.13, 0.13)' % m_smoke)
    node("Smoke", "GPUParticles3D", P, [
        "transform = %s" % tf((0, 0.48, 0), *ident), "amount = 8", "lifetime = 1.8", "preprocess = 1.8",
        "local_coords = false", "cast_shadow = 0",
        "visibility_aabb = AABB(-1, -1, -1, 2, 4, 2)",
        'process_material = SubResource("%s")' % pm_smoke, 'draw_pass_1 = SubResource("%s")' % q_smoke])

# ------------------------------------------------------------------ сборка сцены
def main():
    # --- базовые узлы игрока (перенесены из Main.tscn без изменений)
    node("Player", "CharacterBody3D", None, [
        'script = ExtResource("player_script")', "collision_layer = 2", "collision_mask = 1", "floor_snap_length = 0.6"])
    node("Body", "CollisionShape3D", ".", ["transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.875, 0)",
                                           'shape = SubResource("Capsuleshp_108")'])
    node("Head", "Node3D", ".", ["transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.6, 0)"])
    node("Camera3D", "Camera3D", "Head", ["current = true", "fov = 72.0", "near = 0.05", "far = 400.0"])
    node("RayCast3D", "RayCast3D", "Head/Camera3D", [
        "target_position = Vector3(0, 0, -4.5)", "collision_mask = 5", "collide_with_areas = true",
        "collide_with_bodies = true"])
    # --- HandRig
    node("HandRig", "Node3D", "Head/Camera3D", [
        "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, %s, %s, %s)" % tuple(f(v) for v in RIG_POS),
        "visible = false"])
    build_right_hand()
    build_left_hand()
    build_torch()
    # --- остальное
    node("Reach", "Area3D", ".", ["collision_layer = 0", "collision_mask = 4", "monitoring = true", "monitorable = false"])
    node("Sphere", "CollisionShape3D", "Reach", ["transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0)",
                                                 'shape = SubResource("Sphereshp_109")'])
    node("Fireflies", "GPUParticles3D", ".", [
        "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.5, 0)", "emitting = false", "amount = 150",
        "lifetime = 7.0", "preprocess = 3.0", "visibility_aabb = AABB(-30, -6, -30, 60, 14, 60)",
        'process_material = SubResource("ParticleProcessMaterial_112")', 'draw_pass_1 = SubResource("SphereMesh_111")'])

    fixed = """[sub_resource type="CapsuleShape3D" id="Capsuleshp_108"]
radius = 0.35
height = 1.75

[sub_resource type="SphereShape3D" id="Sphereshp_109"]
radius = 2.6

[sub_resource type="StandardMaterial3D" id="mat_firefly"]
albedo_color = Color(1, 0.847, 0.376, 1)
roughness = 0.9
emission_enabled = true
emission = Color(1, 0.847, 0.376, 1)
emission_energy_multiplier = 3
shading_mode = 0

[sub_resource type="SphereMesh" id="SphereMesh_111"]
radius = 0.07
height = 0.14
radial_segments = 6
rings = 3
material = SubResource("mat_firefly")

[sub_resource type="ParticleProcessMaterial" id="ParticleProcessMaterial_112"]
emission_shape = 3
emission_box_extents = Vector3(25, 3, 25)
direction = Vector3(0, 1, 0)
spread = 180.0
initial_velocity_min = 0.1
initial_velocity_max = 0.6
gravity = Vector3(0, 0, 0)
scale_min = 0.6
scale_max = 1.4

"""
    out = ['[gd_scene load_steps=%d format=3]\n' % (len(subres) + 8),
           '[ext_resource type="Script" path="res://scripts/Player.gd" id="player_script"]',
           '[ext_resource type="Texture2D" path="res://assets/flame_tongue.png" id="flame_tex"]\n',
           fixed]
    out += subres
    for name, ntype, parent, props, extra in nodes:
        if parent is None:
            head = '[node name="%s" type="%s"]' % (name, ntype)
        else:
            head = '[node name="%s" type="%s" parent="%s"]' % (name, ntype, parent)
        out.append(head)
        out.extend(props)
        out.append("")
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scenes", "Player.tscn")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out))
    print("written", os.path.normpath(path), "subresources:", len(subres), "nodes:", len(nodes))

if __name__ == "__main__":
    main()
