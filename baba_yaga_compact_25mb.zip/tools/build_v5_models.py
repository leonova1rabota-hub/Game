import sys,os,json,struct,pickle
sys.path.insert(0,'/home/claude/up')
from gltfutil import *
OUT='/home/claude/w/baba_yaga_3d_v2/assets/custom/models'
os.makedirs(OUT,exist_ok=True)
rng=np.random.default_rng(7)

def write_scene(path,parts):
    """parts: list of (name,P,N,C,F). One node+mesh each, single material (vertex colors)."""
    bufs=[];views=[];accs=[];meshes=[];nodes=[]
    def add(arr,target,typ,ct,cnt,extra=None):
        b=arr.tobytes();pad=(-len(b))%4;off=sum(len(x) for x in bufs);bufs.append(b+b'\0'*pad)
        views.append({'buffer':0,'byteOffset':off,'byteLength':len(b),'target':target})
        a={'bufferView':len(views)-1,'componentType':ct,'count':cnt,'type':typ}
        if extra:a.update(extra)
        accs.append(a);return len(accs)-1
    for name,P,N,C,F in parts:
        P=P.astype(np.float32);N=N.astype(np.float32);C4=np.concatenate([C,np.ones((len(C),1))],1).astype(np.float32)
        idx=F.astype(np.uint16 if len(P)<65535 else np.uint32).reshape(-1)
        ip=add(P,34962,'VEC3',5126,len(P),{'min':P.min(0).tolist(),'max':P.max(0).tolist()})
        iN=add(N,34962,'VEC3',5126,len(N));iC=add(C4,34962,'VEC4',5126,len(C4))
        iI=add(idx,34963,'SCALAR',5123 if idx.dtype==np.uint16 else 5125,len(idx))
        meshes.append({'name':name,'primitives':[{'attributes':{'POSITION':ip,'NORMAL':iN,'COLOR_0':iC},'indices':iI,'material':0}]})
        nodes.append({'mesh':len(meshes)-1,'name':name})
    binb=b''.join(bufs)
    js={'asset':{'version':'2.0','generator':'baba_yaga_v5'},'scene':0,'scenes':[{'nodes':list(range(len(nodes)))}],'nodes':nodes,'meshes':meshes,
        'materials':[{'name':'vertex_color','pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'metallicFactor':0.0,'roughnessFactor':0.9},'doubleSided':True}],
        'accessors':accs,'bufferViews':views,'buffers':[{'byteLength':len(binb)}]}
    pack_glb(path,js,binb);print(os.path.basename(path),os.path.getsize(path)//1024,'KB')

def box(c,s,col):
    cx,cy,cz=c;sx,sy,sz=[v/2 for v in s]
    V=[];Fc=[]
    for ax in range(3):
        for sg in (-1,1):
            u=(ax+1)%3;v=(ax+2)%3
            n=np.zeros(3);n[ax]=sg
            quad=[]
            for a,b in ((-1,-1),(1,-1),(1,1),(-1,1)):
                p=np.zeros(3);p[ax]=sg*[sx,sy,sz][ax];p[u]=a*[sx,sy,sz][u];p[v]=b*[sx,sy,sz][v]
                quad.append(p+np.array([cx,cy,cz]))
            b0=len(V);V+=quad
            Fc+=[[b0,b0+1,b0+2],[b0,b0+2,b0+3]] if sg>0 else [[b0,b0+2,b0+1],[b0,b0+3,b0+2]]
    return np.array(V),np.tile(col,(len(V),1)),np.array(Fc)
def cat(parts):
    Ps=[];Cs=[];Fs=[];b=0
    for P,C,F in parts:
        Ps.append(P);Cs.append(C);Fs.append(F+b);b+=len(P)
    return np.concatenate(Ps),np.concatenate(Cs),np.concatenate(Fs)
def flatn(P,F):
    # flat-shaded: unshare verts
    P2=P[F.reshape(-1)];F2=np.arange(len(P2)).reshape(-1,3);return P2,F2
def finish(P,C,F,flat=True):
    if flat:
        C=C[F.reshape(-1)];P,F=flatn(P,F)
    return P,vertex_normals(P,F),C,F
def lin(r,g,b): return srgb2lin(np.array([r,g,b])/255.0)

# ---------- TOWER
P,C,F=pickle.load(open('tower_dec.pkl','rb'))
axis=np.array([0.0219,-0.0110])
cent=(P[F[:,0]]+P[F[:,1]]+P[F[:,2]])/3
rad=np.hypot(cent[:,0]-axis[0],cent[:,2]-axis[1])
keep=rad<0.215
F=F[keep];used=np.unique(F);rm=-np.ones(len(P),int);rm[used]=np.arange(len(used));P=P[used];C=C[used];F=rm[F]
P=P.copy();P[:,0]-=axis[0];P[:,2]-=axis[1];P[:,1]-=P[:,1].min();h=P[:,1].max();P/=h
write_scene(OUT+'/tower.glb',[('Tower',P,vertex_normals(P,F),C,F)])
meta={'tower':{'radius':float(np.hypot(P[:,0],P[:,2]).max()),'aspect':1.0}}

# ---------- HAG
P,C,F=pickle.load(open('hag_dec.pkl','rb'))
P=P.copy();c=(P.max(0)+P.min(0))/2;P[:,0]-=c[0];P[:,2]-=c[2];P[:,1]-=P[:,1].min();P/=P[:,1].max()
write_scene(OUT+'/witch_swamp.glb',[('SwampWitch',P,vertex_normals(P,F),C,F)])

# ---------- CAVE FACADE
P,C,F=pickle.load(open('cave_dec.pkl','rb'))
P=P.copy();c=(P.max(0)+P.min(0))/2;P[:,0]-=c[0];P[:,2]-=c[2];P[:,1]-=P[:,1].min();P/=P[:,1].max()
write_scene(OUT+'/cave_rock.glb',[('CaveRock',P,vertex_normals(P,F),C,F)])
meta['cave_rock']={'width':float(np.ptp(P[:,0])),'depth':float(np.ptp(P[:,2]))}

# ---------- MOUNTAIN (rock mass cropped from the terrain piece)
g=G('/home/claude/up/split');Pf,Cf,Ff,_=merged_mesh(g)
cf=(Pf[Ff[:,0]]+Pf[Ff[:,1]]+Pf[Ff[:,2]])/3
hi=cf[:,1]>6.0
print('hi tris',hi.sum(),'xz',cf[hi][:,0].min(),cf[hi][:,0].max(),cf[hi][:,2].min(),cf[hi][:,2].max())
x0,x1=np.percentile(cf[hi][:,0],[3,97]);z0,z1=np.percentile(cf[hi][:,2],[3,97])
sel=(cf[:,0]>x0-8)&(cf[:,0]<x1+8)&(cf[:,2]>z0-8)&(cf[:,2]<z1+8)&(cf[:,1]>1.5)
Fs=Ff[sel];used=np.unique(Fs);rm=-np.ones(len(Pf),int);rm[used]=np.arange(len(used))
Pm,Cm,Fm=Pf[used],Cf[used],rm[Fs]
print('mountain crop',len(Fm))
P2,C2,F2=decimate_to(Pm,Cm,Fm,8000)
P2=P2.copy();c=(P2.max(0)+P2.min(0))/2;P2[:,0]-=c[0];P2[:,2]-=c[2];P2[:,1]-=P2[:,1].min()
ex=max(np.ptp(P2[:,0]),np.ptp(P2[:,2]));P2/=ex
write_scene(OUT+'/mountain.glb',[('Mountain',P2,vertex_normals(P2,F2),C2,F2)])
meta['mountain']={'height':float(P2[:,1].max()),'width':float(np.ptp(P2[:,0])),'depth':float(np.ptp(P2[:,2]))}

# ---------- ROCKS (3 round boulders)
g=G('/home/claude/up/rocks');Pr,Cr,Fr,Mr=merged_mesh(g)
parts=[]
vm=Mr
for k,mi in enumerate(sorted(set(vm.tolist()))):
    vsel=np.where(vm==mi)[0]
    fm=np.isin(Fr[:,0],vsel);Fk=Fr[fm];u=np.unique(Fk);rm=-np.ones(len(Pr),int);rm[u]=np.arange(len(u))
    Pk=Pr[u].copy();Ck=Cr[u];Fk=rm[Fk]
    c=(Pk.max(0)+Pk.min(0))/2;Pk[:,0]-=c[0];Pk[:,2]-=c[2];Pk[:,1]-=Pk[:,1].min()
    Pk/=max(np.ptp(Pk[:,0]),np.ptp(Pk[:,2]))
    # round off: soften by spherical blend
    parts.append(('Rock%d'%k,Pk,vertex_normals(Pk,Fk),Ck,Fk));print('rock',k,len(Fk),np.ptp(Pk,axis=0))
write_scene(OUT+'/rocks.glb',parts)

# ---------- AXE + STUMP (meters, origin at ground under stump)
g=G('/home/claude/up/axe');Pa,Ca,Fa,_=merged_mesh(g)
Pa=Pa.copy();L=Pa[:,1].max()-Pa[:,1].min()
Pa[:,1]-=Pa[:,1].min()
low=Pa[:,1]<0.15*L;Pa[:,0]-=Pa[low][:,0].mean();Pa[:,2]-=Pa[low][:,2].mean()
blade_top=Pa[Pa[:,0]>0.15*L][:,1].mean()>L/2
if blade_top:
    Pa[:,1]=L-Pa[:,1];Pa[:,0]=-Pa[:,0];Fa=Fa[:,[0,2,1]]
Pa/=L   # unit length, blade end at y=0
th=np.radians(-22);R=np.array([[np.cos(th),-np.sin(th),0],[np.sin(th),np.cos(th),0],[0,0,1]])
Pa=(Pa*0.95)@R.T+np.array([0.05,0.52,0.0])   # blade bit sunk into stump top (top y=0.6)
Na=vertex_normals(Pa,Fa)
# stump lathe
seg=28;prof=[(0.0,0.62),(0.12,0.50),(0.35,0.45),(0.58,0.44),(0.60,0.42),(0.60,0.0)]
ring_y=[0.0,0.08,0.22,0.40,0.56,0.60];ring_r=[0.64,0.52,0.46,0.45,0.44,0.43]
V=[];Cc=[]
bark=lin(70,52,38)
for i,(y,r) in enumerate(zip(ring_y,ring_r)):
    for s in range(seg):
        a=2*np.pi*s/seg;rr=r*(1+0.07*np.sin(5*a+i)+0.04*np.sin(9*a)) 
        V.append([rr*np.cos(a),y,rr*np.sin(a)]);t=0.7+0.5*(0.5+0.5*np.sin(7*a+2*i))
        Cc.append(bark*t*(0.8+0.2*(i/5)))
topc=len(V);V.append([0,0.60,0]);Cc.append(lin(150,115,75))
Fst=[]
for i in range(len(ring_y)-1):
    for s in range(seg):
        a=i*seg+s;b=i*seg+(s+1)%seg;c2=(i+1)*seg+s;d=(i+1)*seg+(s+1)%seg
        Fst+=[[a,c2,b],[b,c2,d]]
last=(len(ring_y)-1)*seg
for s in range(seg): Fst.append([last+s,last+(s+1)%seg,topc])
Vs=np.array(V);Cs=np.array(Cc);Fs_=np.array(Fst)
# top rings (age rings) colour
for s in range(seg): Cs[last+s]=lin(120,92,60)
Ps_,Ns_,Cs_,Fs2=finish(Vs,Cs,Fs_,flat=False)
Ns_=vertex_normals(Vs,Fs_)
write_scene(OUT+'/axe.glb',[('Stump',Vs,Ns_,Cs,Fs_),('Axe',Pa,Na,Ca,Fa)])

# ---------- CHEST (Body about chest centre, Lid about hinge)
wood=lin(92,60,36);wood2=lin(70,46,28);iron=lin(58,60,64);gold=lin(190,150,60)
parts=[box((0,-0.05,0),(1.2,0.7,0.8),wood)]
for x in (-0.42,0.42): parts.append(box((x,-0.05,0),(0.1,0.72,0.84),iron))
parts.append(box((0,-0.40,0),(1.26,0.06,0.86),wood2))
parts.append(box((0,0.12,0.41),(0.14,0.2,0.04),gold))
Pb,Cb,Fb=cat(parts);Pb,Nb,Cb,Fb=finish(Pb,Cb,Fb)
# lid: half-cylinder along x about hinge at (0,0,0) lid spans z 0..0.8
lp=[];lc=[];lf=[];n=10
def arc(z_arc):pass
ys=[];
for i in range(n+1):
    a=np.pi*i/n   # 0..pi: from front-bottom to back-bottom
    z=0.4-0.4*np.cos(a);y=0.01+0.22*np.sin(a)
    ys.append((y,z))
for xi,x in enumerate((-0.6,0.6)):
    for (y,z) in ys: lp.append([x,y,z])
for i in range(n):
    a=i;b=i+1;c2=n+1+i;d=n+1+i+1
    lf+=[[a,c2,b],[b,c2,d]]
# end caps
for xi in (0,1):
    base=xi*(n+1)
    for i in range(1,n): lf.append([base,base+i,base+i+1] if xi==0 else [base,base+i+1,base+i])
lp=np.array(lp);lcol=np.tile(wood,(len(lp),1))
for i in range(len(lp)):
    if abs(lp[i][0])<0.5 and ((abs(lp[i][0])>0.37) ): lcol[i]=iron
Pl,Cl,Fl=lp,lcol,np.array(lf)
bands=[box((x,0.12,0.4),(0.1,0.26,0.84),iron) for x in (-0.42,0.42)]
Pl,Cl,Fl=cat([(Pl,Cl,Fl)]+bands);Pl,Nl,Cl,Fl=finish(Pl,Cl,Fl)
Pl[:,1]+=0.0
write_scene(OUT+'/chest.glb',[('ChestBody',Pb,Nb,Cb,Fb),('ChestLid',Pl,Nl,Cl,Fl)])

# ---------- BRIDGE (length 7 along X, width 2.4, deck top at y=0)
plank=lin(98,70,44);plank2=lin(80,56,36);rope=lin(110,92,60);post=lin(70,50,34)
parts=[]
nplank=14;pl=7.0/nplank
for i in range(nplank):
    x=-3.5+pl*(i+0.5);col=(plank if i%2 else plank2)*rng.uniform(0.85,1.1)
    parts.append(box((x,-0.07,0),(pl*0.92,0.14,2.3),col))
for z in (-1.0,1.0): parts.append(box((0,-0.22,z),(7.0,0.16,0.16),post))
for x in np.linspace(-3.3,3.3,6):
    for z in (-1.12,1.12): parts.append(box((x,0.45,z),(0.12,1.0,0.12),post))
for z in (-1.12,1.12):
    parts.append(box((0,0.9,z),(7.0,0.08,0.08),rope)); parts.append(box((0,0.5,z),(7.0,0.05,0.05),rope))
Pbr,Cbr,Fbr=cat(parts);Pbr,Nbr,Cbr,Fbr=finish(Pbr,Cbr,Fbr)
write_scene(OUT+'/bridge.glb',[('Bridge',Pbr,Nbr,Cbr,Fbr)])

# ---------- REEDS (1.6 m clump)
V=[];Cc=[];Fr_=[];
def blade(x,z,h,lean,ang,w,col):
    b0=len(V);seg=5
    for i in range(seg+1):
        t=i/seg;y=h*t;off=lean*t*t;ww=w*(1-t*0.92)
        cx=x+np.cos(ang)*off;cz=z+np.sin(ang)*off
        px,pz=-np.sin(ang+1.2),np.cos(ang+1.2)
        V.append([cx-px*ww,y,cz-pz*ww]);V.append([cx+px*ww,y,cz+pz*ww])
        Cc.append(col*(0.6+0.5*t));Cc.append(col*(0.6+0.5*t))
    for i in range(seg):
        a=b0+2*i;Fr_.extend([[a,a+1,a+2],[a+1,a+3,a+2]])
green=lin(78,96,44);dry=lin(122,104,58)
for k in range(16):
    r=rng.uniform(0,0.28);a=rng.uniform(0,2*np.pi)
    h=rng.uniform(0.9,1.0)*(1.0 if k%3 else 0.85)
    blade(r*np.cos(a),r*np.sin(a),h,rng.uniform(0.1,0.35),a,rng.uniform(0.025,0.04),green if k%4 else dry)
Vr=np.array(V);Cr=np.array(Cc);Fr2=np.array(Fr_)
parts=[(Vr,Cr,Fr2)]
for k in range(3):  # cattail heads
    a=rng.uniform(0,2*np.pi);r=rng.uniform(0.04,0.2);x,z=r*np.cos(a),r*np.sin(a);y0=0.95+0.05*k
    pts=[];fc=[]
    for yy,rr in ((y0,0.0),(y0+0.02,0.035),(y0+0.15,0.035),(y0+0.17,0.0)):
        pass
    cv=[];cf=[];s=8;rings=[(y0,0.0),(y0+0.02,0.035),(y0+0.16,0.035),(y0+0.19,0.0)]
    for yy,rr in rings:
        for q in range(s):
            aa=2*np.pi*q/s;cv.append([x+rr*np.cos(aa),yy,z+rr*np.sin(aa)])
    for i in range(3):
        for q in range(s):
            a1=i*s+q;b1=i*s+(q+1)%s;c1=(i+1)*s+q;d1=(i+1)*s+(q+1)%s;cf+=[[a1,c1,b1],[b1,c1,d1]]
    parts.append((np.array(cv),np.tile(lin(86,56,34),(len(cv),1)),np.array(cf)))
    # stem
    parts.append(box((x,y0/2,z),(0.015,y0,0.015),green))
Pr2,Cr2,Fr3=cat(parts);Pr2,Nr2,Cr2,Fr3=finish(Pr2,Cr2,Fr3)
Pr2=Pr2*(1.6)  # metres: 1.6 m tall
write_scene(OUT+'/reeds.glb',[('Reeds',Pr2,Nr2,Cr2,Fr3)])
json.dump(meta,open('/home/claude/up/meta_v5.json','w'),indent=1);print(meta)
