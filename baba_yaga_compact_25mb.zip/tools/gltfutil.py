import json,os,struct,io
import numpy as np
from PIL import Image
CT={5126:np.float32,5123:np.uint16,5125:np.uint32,5121:np.uint8,5120:np.int8,5122:np.int16}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def node_matrix(n):
    if 'matrix' in n: return np.array(n['matrix'],dtype=np.float64).reshape(4,4).T
    M=np.eye(4);t=n.get('translation',[0,0,0]);r=n.get('rotation',[0,0,0,1]);s=n.get('scale',[1,1,1])
    x,y,z,w=r
    R=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
    M[:3,:3]=R*np.array(s);M[:3,3]=t;return M
class G:
    def __init__(self,d):
        self.d=d;self.g=json.load(open(d+'/scene.gltf'));self.buf=open(d+'/scene.bin','rb').read();self.imgs={}
    def acc(self,i):
        g=self.g;a=g['accessors'][i];bv=g['bufferViews'][a['bufferView']]
        dt=CT[a['componentType']];nc=NC[a['type']];off=bv.get('byteOffset',0)+a.get('byteOffset',0);stride=bv.get('byteStride',0);es=np.dtype(dt).itemsize*nc
        if stride and stride!=es:
            raw=np.frombuffer(self.buf,dtype=np.uint8,count=stride*a['count'],offset=off).reshape(a['count'],stride)
            arr=raw[:,:es].copy().view(dt).reshape(a['count'],nc)
        else:
            arr=np.frombuffer(self.buf,dtype=dt,count=a['count']*nc,offset=off).reshape(a['count'],nc)
        return arr
    def image(self,idx):
        if idx not in self.imgs:
            self.imgs[idx]=Image.open(os.path.join(self.d,self.g['images'][idx]['uri']))
        return self.imgs[idx]
    def basecolor(self,mi):
        m=self.g['materials'][mi];pb=m.get('pbrMetallicRoughness',{})
        f=np.array(pb.get('baseColorFactor',[1,1,1,1])[:3])
        if 'baseColorTexture' in pb:
            im=self.image(self.g['textures'][pb['baseColorTexture']['index']]['source']).convert('RGB')
            return np.asarray(im),f
        return None,f
    def walk(self):
        """yield (node, world matrix)"""
        out=[]
        def rec(i,P):
            n=self.g['nodes'][i];M=P@node_matrix(n);out.append((i,n,M))
            for c in n.get('children',[]): rec(c,M)
        for s in self.g['scenes'][0]['nodes']: rec(s,np.eye(4))
        return out
def srgb2lin(c):
    c=np.asarray(c,dtype=np.float64)
    return np.where(c<=0.04045,c/12.92,((c+0.055)/1.055)**2.4)
def merged_mesh(G_,sample_color=True,only=None):
    """returns P (world), C (linear rgb), F (tri indices), mat_ids per vertex"""
    Ps=[];Cs=[];Fs=[];Ms=[];base=0
    for i,n,M in G_.walk():
        if 'mesh' not in n: continue
        if only is not None and i!=only: continue
        for p in G_.g['meshes'][n['mesh']]['primitives']:
            if p.get('mode',4)!=4: continue
            pos=G_.acc(p['attributes']['POSITION']).astype(np.float64)
            P=(M[:3,:3]@pos.T).T+M[:3,3]
            col=np.ones((len(P),3))*0.6
            mi=p.get('material',None)
            if mi is not None:
                tex,f=G_.basecolor(mi)
                if tex is not None and 'TEXCOORD_0' in p['attributes']:
                    uv=G_.acc(p['attributes']['TEXCOORD_0']).astype(np.float64)
                    h,w=tex.shape[:2]
                    x=np.clip((uv[:,0]%1.0)*(w-1),0,w-1).astype(int);y=np.clip((uv[:,1]%1.0)*(h-1),0,h-1).astype(int)
                    col=srgb2lin(tex[y,x]/255.0)*f
                else: col=np.tile(f,(len(P),1))
            if 'indices' in p: idx=G_.acc(p['indices']).reshape(-1).astype(np.int64)
            else: idx=np.arange(len(P))
            F=idx.reshape(-1,3)+base
            if np.linalg.det(M[:3,:3])<0: F=F[:,[0,2,1]]
            Ps.append(P);Cs.append(col);Fs.append(F);Ms.append(np.full(len(P),mi if mi is not None else -1));base+=len(P)
    return np.concatenate(Ps),np.concatenate(Cs),np.concatenate(Fs),np.concatenate(Ms)
def cluster_decimate(P,C,F,cell):
    mn=P.min(0);key=np.floor((P-mn)/cell).astype(np.int64)
    dims=key.max(0)+1
    lin=(key[:,0]*dims[1]+key[:,1])*dims[2]+key[:,2]
    uniq,inv=np.unique(lin,return_inverse=True);n=len(uniq)
    cnt=np.bincount(inv,minlength=n).astype(np.float64)
    mean=np.zeros((n,3));np.add.at(mean,inv,P);mean/=cnt[:,None]
    col=np.zeros((n,3));np.add.at(col,inv,C);col/=cnt[:,None]
    # QEM per cluster
    p0,p1,p2=P[F[:,0]],P[F[:,1]],P[F[:,2]]
    nr=np.cross(p1-p0,p2-p0);ar=np.linalg.norm(nr,axis=1);ok=ar>1e-14
    nn=np.zeros_like(nr);nn[ok]=nr[ok]/ar[ok,None];d=-(nn*p0).sum(1);w=ar*0.5
    pl=np.concatenate([nn,d[:,None]],1)
    Q=np.einsum('ti,tj->tij',pl,pl)*w[:,None,None]
    Qc=np.zeros((n,4,4))
    for k in range(3): np.add.at(Qc,inv[F[:,k]],Q)
    A=Qc[:,:3,:3];b=Qc[:,:3,3]
    tr=np.trace(A,axis1=1,axis2=2)+1e-12
    lam=(tr*0.02+1e-12)[:,None,None]*np.eye(3)[None]
    rhs=-b+(lam@mean[:,:,None])[:,:,0]
    try:
        x=np.linalg.solve(A+lam,rhs[:,:,None])[:,:,0]
        x=np.clip(x,mean-cell*0.9,mean+cell*0.9)
    except np.linalg.LinAlgError: x=mean
    F2=inv[F]
    keep=(F2[:,0]!=F2[:,1])&(F2[:,1]!=F2[:,2])&(F2[:,0]!=F2[:,2])
    F2=F2[keep]
    s=np.sort(F2,axis=1);_,ui=np.unique(s,axis=0,return_index=True);F2=F2[np.sort(ui)]
    # drop unused
    used=np.unique(F2);remap=-np.ones(n,dtype=np.int64);remap[used]=np.arange(len(used))
    return x[used],col[used],remap[F2]
def decimate_to(P,C,F,target):
    ext=(P.max(0)-P.min(0)).max();lo=ext/4000;hi=ext/4
    best=None
    for _ in range(18):
        mid=(lo*hi)**0.5
        P2,C2,F2=cluster_decimate(P,C,F,mid)
        if len(F2)>target: lo=mid
        else: hi=mid;best=(P2,C2,F2)
    return best if best else cluster_decimate(P,C,F,hi)
def vertex_normals(P,F):
    p0,p1,p2=P[F[:,0]],P[F[:,1]],P[F[:,2]];fn=np.cross(p1-p0,p2-p0)
    N=np.zeros_like(P)
    for k in range(3): np.add.at(N,F[:,k],fn)
    l=np.linalg.norm(N,axis=1);l[l==0]=1;return N/l[:,None]
def write_glb(path,P,N,C,F,name='mesh'):
    P=P.astype(np.float32);N=N.astype(np.float32);C4=np.concatenate([C,np.ones((len(C),1))],1).astype(np.float32);
    idx=F.astype(np.uint16 if len(P)<65535 else np.uint32).reshape(-1)
    parts=[];views=[];accs=[]
    def add(arr,target,typ,ct,cnt,extra=None):
        b=arr.tobytes();pad=(-len(b))%4
        off=sum(len(x) for x in parts);parts.append(b+b'\0'*pad)
        views.append({'buffer':0,'byteOffset':off,'byteLength':len(b),'target':target})
        a={'bufferView':len(views)-1,'componentType':ct,'count':cnt,'type':typ}
        if extra: a.update(extra)
        accs.append(a);return len(accs)-1
    ip=add(P,34962,'VEC3',5126,len(P),{'min':P.min(0).tolist(),'max':P.max(0).tolist()})
    iN=add(N,34962,'VEC3',5126,len(N))
    iC=add(C4,34962,'VEC4',5126,len(C4))
    iI=add(idx,34963,'SCALAR',5123 if idx.dtype==np.uint16 else 5125,len(idx))
    binb=b''.join(parts)
    js={'asset':{'version':'2.0','generator':'baba_yaga_build'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'mesh':0,'name':name}],
        'meshes':[{'name':name,'primitives':[{'attributes':{'POSITION':ip,'NORMAL':iN,'COLOR_0':iC},'indices':iI,'material':0}]}],
        'materials':[{'name':'vertex_color','pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'metallicFactor':0.0,'roughnessFactor':0.92},'doubleSided':True}],
        'accessors':accs,'bufferViews':views,'buffers':[{'byteLength':len(binb)}]}
    pack_glb(path,js,binb)
def pack_glb(path,js,binb):
    jb=json.dumps(js,separators=(',',':')).encode();jb+=b' '*((-len(jb))%4);binb=binb+b'\0'*((-len(binb))%4)
    with open(path,'wb') as f:
        f.write(struct.pack('<III',0x46546C67,2,12+8+len(jb)+8+len(binb)))
        f.write(struct.pack('<II',len(jb),0x4E4F534A));f.write(jb)
        f.write(struct.pack('<II',len(binb),0x004E4942));f.write(binb)
