extends CharacterBody3D
## Игрок от первого лица. Двойное обнаружение: RayCast3D (4.5 м) + сфера Reach (2.6 м).

const SPEED: float = 4.8
const GRAVITY: float = 22.0
const JUMP_VELOCITY: float = 7.5
const COYOTE_TIME: float = 0.15   # прыжок разрешён чуть после схода с края/склона
const JUMP_BUFFER: float = 0.2    # нажатие запоминается, если чуть раньше приземления
const LOOK_SENS: float = 0.0042
const KEY_TURN_SPEED: float = 1.9
const TORCH_ITEM: String = "Горящий факел"
const TORCH_BASE_ENERGY: float = 3.5
const SWAY_MAX: float = 0.10          # макс. наклон рук при повороте камеры, рад

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var ray: RayCast3D = $Head/Camera3D/RayCast3D
@onready var reach: Area3D = $Reach
@onready var hand_rig: Node3D = $Head/Camera3D/HandRig
@onready var torch_node: Node3D = $Head/Camera3D/HandRig/Torch
@onready var torch_light: OmniLight3D = $Head/Camera3D/HandRig/Torch/OmniLight3D

var pitch: float = 0.0
var current_focus: Node = null
var safe_pos: Vector3 = Vector3.ZERO
var safe_timer: float = 0.0
var coyote_left: float = 0.0
var jump_buffer_left: float = 0.0

# --- руки и факел (v9)
var bob_time: float = 0.0
var default_hand_pos: Vector3 = Vector3(0.18, -0.28, -0.42)
var torch_equipped: bool = false
var equip_offset: float = 0.0          # руки «выезжают» снизу при экипировке (1 -> 0)
var _equip_tween: Tween = null
var _look_sway: Vector2 = Vector2.ZERO # сглаженное смещение камеры за кадр физики

func _ready() -> void:
    add_to_group("player")
    safe_pos = global_position
    ray.add_exception(self)
    floor_max_angle = deg_to_rad(46.0)
    floor_snap_length = 0.6
    floor_stop_on_slope = true
    hand_rig.position = default_hand_pos
    hand_rig.visible = true
    _hide_torch_bracket()
    _fix_hand_materials()
    torch_node.visible = false
    torch_light.visible = false
    GameManager.inventory_changed.connect(_update_torch_equipment)
    _update_torch_equipment()

func _input(event: InputEvent) -> void:
    if GameManager.input_locked():
        return
    if event is InputEventMouseMotion:
        var mm: InputEventMouseMotion = event
        if (mm.button_mask & MOUSE_BUTTON_MASK_RIGHT) != 0:
            GameManager.look_delta += mm.relative
    elif event is InputEventKey:
        var k: InputEventKey = event
        if k.pressed and not k.echo:
            if k.physical_keycode == KEY_E or k.physical_keycode == KEY_F or k.physical_keycode == KEY_ENTER:
                GameManager.try_interact()
            elif k.physical_keycode == KEY_SPACE or k.keycode == KEY_SPACE:
                jump_buffer_left = JUMP_BUFFER

func _physics_process(delta: float) -> void:
    var locked: bool = GameManager.input_locked()
    var iv: Vector2 = Vector2.ZERO
    var turn: float = 0.0
    if not locked:
        iv = GameManager.move_vec
        if Input.is_physical_key_pressed(KEY_W):
            iv.y -= 1.0
        if Input.is_physical_key_pressed(KEY_S):
            iv.y += 1.0
        if Input.is_physical_key_pressed(KEY_A):
            iv.x -= 1.0
        if Input.is_physical_key_pressed(KEY_D):
            iv.x += 1.0
        if Input.is_physical_key_pressed(KEY_LEFT):
            turn += 1.0
        if Input.is_physical_key_pressed(KEY_RIGHT):
            turn -= 1.0
        iv = iv.limit_length(1.0)
    var look: Vector2 = GameManager.look_delta
    GameManager.look_delta = Vector2.ZERO
    _look_sway = _look_sway.lerp(look + Vector2(-turn * 6.0, 0.0), 0.35)
    if not locked:
        rotate_y(-look.x * LOOK_SENS + turn * KEY_TURN_SPEED * delta)
        pitch = clampf(pitch - look.y * LOOK_SENS, -1.4, 1.4)
        head.rotation.x = pitch

    var dir: Vector3 = global_transform.basis * Vector3(iv.x, 0.0, iv.y)
    velocity.x = dir.x * SPEED
    velocity.z = dir.z * SPEED
    if GameManager.jump_requested:
        GameManager.jump_requested = false
        if not locked:
            jump_buffer_left = JUMP_BUFFER
    if locked:
        jump_buffer_left = 0.0

    var on_floor: bool = is_on_floor()
    if on_floor:
        coyote_left = COYOTE_TIME
        if velocity.y < 0.0:
            velocity.y = 0.0
    else:
        coyote_left = maxf(coyote_left - delta, 0.0)
        velocity.y -= GRAVITY * delta
    jump_buffer_left = maxf(jump_buffer_left - delta, 0.0)

    # Прыжок: работает и на склонах (в т.ч. на пандусе выхода из пещеры).
    if jump_buffer_left > 0.0 and coyote_left > 0.0:
        velocity.y = JUMP_VELOCITY
        jump_buffer_left = 0.0
        coyote_left = 0.0
        on_floor = false
    move_and_slide()

    safe_timer += delta
    if safe_timer > 0.8 and is_on_floor() and global_position.y > -12.0:
        safe_timer = 0.0
        safe_pos = global_position + Vector3(0.0, 0.3, 0.0)
    if global_position.y < -28.0:
        global_position = safe_pos
        velocity = Vector3.ZERO
        GameManager.show_message("Ты сорвалась вниз, но выбралась обратно!")

    _update_focus()

func _update_focus() -> void:
    var target: Node = null
    if not GameManager.input_locked():
        ray.force_raycast_update()
        if ray.is_colliding():
            var c: Object = ray.get_collider()
            if c is Node and (c as Node).is_in_group("interactable"):
                target = c as Node
        if target == null:
            target = _nearest_in_reach()
    if target != current_focus:
        current_focus = target
        GameManager.focus_target = target
        GameManager.focus_changed.emit(target)

func _nearest_in_reach() -> Node:
    var best: Node = null
    var best_score: float = 1000000.0
    var cam_pos: Vector3 = camera.global_position
    var fwd: Vector3 = -camera.global_transform.basis.z
    var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
    for b in reach.get_overlapping_bodies():
        if not (b is CollisionObject3D):
            continue
        var body: CollisionObject3D = b as CollisionObject3D
        if not body.is_in_group("interactable"):
            continue
        var to: Vector3 = body.global_position - cam_pos
        var dist: float = to.length()
        if dist < 0.05:
            continue
        var dot: float = fwd.dot(to / dist)
        if dot < 0.2:
            continue
        var excl: Array[RID] = [get_rid(), body.get_rid()]
        var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(cam_pos, body.global_position, 1, excl)
        var hit: Dictionary = space.intersect_ray(query)
        if not hit.is_empty():
            var col: Object = hit.get("collider")
            if not (col is Node and (col as Node).is_in_group("interactable")):
                continue
        var score: float = dist * (2.0 - dot)
        if score < best_score:
            best_score = score
            best = body
    return best

# ------------------------------------------------------------ руки и факел
## Факел в руках, пока «Горящий факел» лежит в инвентаре (подобран / выбран).
func _update_torch_equipment() -> void:
    _set_torch_equipped(GameManager.has_item(TORCH_ITEM))

## Настенный кронштейн из torch.glb не нужен в руке: скрываем его.
func _hide_torch_bracket() -> void:
    var holder: Node = torch_node.find_child("torchholder", true, false)
    if holder == null:
        holder = torch_node.find_child("torchholder_Mat_0", true, false)
    if holder is Node3D:
        (holder as Node3D).visible = false

func _fix_hand_materials() -> void:
    for path in ["RightHand", "LeftHand"]:
        var hand: Node = hand_rig.get_node_or_null(path)
        if hand == null:
            continue
        for mi in hand.find_children("*", "MeshInstance3D", true, false):
            var m: Material = (mi as MeshInstance3D).get_active_material(0)
            if m is StandardMaterial3D:
                var c: StandardMaterial3D = m.duplicate()
                c.normal_enabled = false
                c.ao_enabled = false
                c.cull_mode = BaseMaterial3D.CULL_DISABLED
                (mi as MeshInstance3D).material_override = c

func _set_torch_equipped(on: bool) -> void:
    if on == torch_equipped:
        return
    torch_equipped = on
    hand_rig.visible = true        # руки остаются на экране всегда
    torch_node.visible = on        # скрывается только факел
    torch_light.visible = on
    if _equip_tween != null and _equip_tween.is_valid():
        _equip_tween.kill()
    if on:
        equip_offset = 1.0
        _equip_tween = create_tween()
        _equip_tween.tween_property(self, "equip_offset", 0.0, 0.45).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    else:
        equip_offset = 0.0

func _process(delta: float) -> void:
    var t: float = Time.get_ticks_msec() * 0.001
    # 1. Мерцание света факела (суммарно не более ±0.2 к базовой энергии)
    if torch_equipped:
        torch_light.light_energy = TORCH_BASE_ENERGY + sin(t * 13.0) * 0.10 + sin(t * 31.7 + 1.3) * 0.06 + randf_range(-0.04, 0.04)

    # 2. Боббинг при ходьбе (sin/cos от горизонтальной скорости) и дыхание в покое
    var speed: float = Vector2(velocity.x, velocity.z).length()
    var target: Vector3 = default_hand_pos + Vector3(0.0, -0.2 * equip_offset, 0.0)
    var walk_roll: float = 0.0
    var rate: float
    if is_on_floor() and speed > 0.5:
        bob_time += delta * speed * 2.2
        target += Vector3(cos(bob_time * 0.5) * 0.022, sin(bob_time) * 0.018, 0.0)
        walk_roll = cos(bob_time * 0.5) * 0.02
        rate = 10.0
    else:
        var breath: float = sin(t * 1.9) * 0.006
        var air: float = 0.0 if is_on_floor() else clampf(-velocity.y * 0.004, -0.04, 0.04)
        target += Vector3(cos(t * 0.95) * 0.003, breath + air, 0.0)
        walk_roll = sin(t * 0.95) * 0.004
        rate = 5.0
    hand_rig.position = hand_rig.position.lerp(target, minf(delta * rate, 1.0))

    # 3. Инерция рук при повороте камеры (Sway) + лёгкий крен при шаге
    var sway_target: Vector3 = Vector3(
        clampf(_look_sway.y * 0.010, -SWAY_MAX, SWAY_MAX),
        clampf(_look_sway.x * 0.010, -SWAY_MAX, SWAY_MAX),
        clampf(_look_sway.x * 0.006, -SWAY_MAX, SWAY_MAX) + walk_roll)
    hand_rig.rotation = hand_rig.rotation.lerp(sway_target, minf(delta * 8.0, 1.0))
