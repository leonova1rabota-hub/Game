extends Node3D
## Тропы — старая заросшая мостовая: прореженные выступающие булыжники (MultiMesh), а не сплошная полоса.
## Камни объёмные и наполовину вросли в землю: их пересечение с рельефом — линия, а не копланарная
## плоскость, поэтому z-fighting невозможен. В Godot 4 у BaseMaterial3D нет polygon_offset; вместо него
## для шейдера выставлен render_priority. Коллизии у камней нет: игрок не спотыкается.

@export var path_material: Material    # оставлено для совместимости со сценой (не используется)

const COBBLE_SHADER: String = "res://assets/cobble.gdshader"
const LANES: Array = [-1.3, -0.45, 0.45, 1.3]
const STEP: float = 0.55
const SKIP_CHANCE: float = 0.38

const TRAILS: Array = [[[0.0, 0.0, 7.0], [-1.419, 0.0, 10.38], [-3.448, 0.0, 13.586], [-5.523, 0.0, 16.779], [-7.057, 0.0, 20.127], [-7.755, 0.0, 23.713], [-7.779, 0.0, 27.492], [-7.659, 0.0, 31.312], [-8.0, 0.0, 35.0], [-9.101, 0.0, 38.43], [-9.501, 0.0, 42.12], [-9.667, 0.0, 45.897], [-10.192, 0.0, 49.54], [-11.478, 0.0, 52.902], [-13.513, 0.0, 55.986], [-15.886, 0.0, 58.945], [-18.0, 0.0, 62.0], [-19.547, 0.0, 65.602], [-22.32, 0.0, 68.59], [-24.526, 0.0, 71.862]], [[0.0, 0.0, 7.0], [4.0, 0.0, 7.0], [8.946, 0.0, 5.946], [10.0, 0.0, 1.0], [12.575, 0.0, -2.172]], [[0.0, 0.0, 7.0], [-4.0, 0.0, 6.6], [-8.0, 0.0, 5.4], [-12.0, 0.0, 4.2], [-16.0, 0.0, 3.4], [-20.0, 0.0, 2.8], [-25.386, 0.0, 2.252], [-28.604, 0.0, 0.625]], [[-45.627, 0.0, -6.03], [-47.351, 0.891, -9.97], [-50.582, 2.442, -12.529], [-55.0, 4.247, -14.0], [-56.621, 5.422, -18.574], [-60.421, 7.077, -21.188]], [[-8.0, 0.0, 35.0], [-10.787, 0.0, 37.46], [-13.294, 0.0, 40.393], [-15.918, 0.0, 43.128], [-18.987, 0.0, 45.111], [-22.551, 0.0, 46.254], [-26.357, 0.0, 46.99], [-30.0, 0.0, 48.0], [-33.098, 0.0, 49.526]], [[-46.713, 0.0, 52.946], [-49.43, 0.0, 55.311], [-52.0, 0.0, 58.0], [-55.259, 0.0, 54.523]], [[0.0, 0.0, 7.0], [4.031, 0.0, 7.394], [8.223, 0.0, 6.716], [12.359, 0.0, 6.405], [16.271, 0.0, 7.596], [20.0, 0.0, 10.0], [23.841, 0.0, 8.015], [27.827, 0.0, 7.469], [31.938, 0.0, 8.179], [36.036, 0.0, 8.764], [40.0, 0.0, 8.0], [44.384, 0.0, 9.638], [48.45, 0.0, 9.364]], [[4.0, 0.0, 7.0], [5.972, 0.0, 3.913], [7.267, 0.0, 0.625], [7.76, 0.0, -2.9], [7.753, 0.0, -6.573], [7.812, 0.0, -10.227], [8.467, 0.0, -13.704], [9.935, 0.0, -16.941], [12.0, 0.0, -20.0], [10.339, 0.0, -23.595], [9.248, 0.0, -27.266], [9.049, 0.0, -31.056], [9.558, 0.0, -34.941], [10.192, 0.0, -38.842], [10.297, 0.0, -42.673], [9.518, 0.0, -46.386], [8.0, 0.0, -50.0], [9.932, 0.0, -53.247], [11.422, 0.0, -56.588], [12.1, 0.0, -60.104], [12.033, 0.0, -63.779], [11.688, 0.0, -67.513], [11.68, 0.0, -71.176], [12.445, 0.0, -74.673]], [[-10.2, 0.0, 4.0], [-11.0, 0.0, 4.8], [-11.0, 0.0, 5.5]]]

func _ready() -> void:
	if not preload("res://scripts/FeatureFlags.gd").COBBLES:
		return
	await get_tree().physics_frame
	await get_tree().physics_frame
	await get_tree().physics_frame
	_lay_cobbles()

func _make_cobble_mesh() -> ArrayMesh:
	var st: SurfaceTool = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_smooth_group(0)
	var segs: int = 8
	var phis: Array = [0.0, 0.42, 0.85, 1.2, 1.5708]
	var rows: Array = []
	for r in phis.size():
		var phi: float = float(phis[r])
		var row: Array = []
		for s in segs:
			var th: float = TAU * float(s) / float(segs)
			var wob: float = 1.0 + 0.16 * sin(th * 3.0 + float(r) * 1.7) + 0.08 * cos(th * 5.0)
			var rad: float = sin(phi) * wob
			row.append(Vector3(cos(th) * rad, cos(phi) * 0.5, sin(th) * rad))
		rows.append(row)
	for r in range(phis.size() - 1):
		for s in segs:
			var s2: int = (s + 1) % segs
			var a: Vector3 = rows[r][s]
			var b: Vector3 = rows[r][s2]
			var c: Vector3 = rows[r + 1][s]
			var d: Vector3 = rows[r + 1][s2]
			for tri in [[a, c, b], [b, c, d]]:
				for v in tri:
					var vv: Vector3 = v
					var edge: float = clampf(Vector2(vv.x, vv.z).length(), 0.0, 1.0)
					st.set_color(Color(edge * edge, 0.0, 0.0, 1.0))
					st.add_vertex(vv)
	st.generate_normals()
	return st.commit()

func _lay_cobbles() -> void:
	var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 4242
	var xfs: Array = []
	var edges: Array = []
	for trail in TRAILS:
		var pts: Array = trail
		for k in range(pts.size() - 1):
			var a: Vector3 = Vector3(float(pts[k][0]), float(pts[k][1]), float(pts[k][2]))
			var b: Vector3 = Vector3(float(pts[k + 1][0]), float(pts[k + 1][1]), float(pts[k + 1][2]))
			var seg_len: float = Vector2(b.x - a.x, b.z - a.z).length()
			if seg_len < 0.01:
				continue
			var dir: Vector2 = Vector2(b.x - a.x, b.z - a.z) / seg_len
			var perp: Vector2 = Vector2(-dir.y, dir.x)
			var n: int = maxi(1, int(seg_len / STEP))
			for i in n:
				var base: Vector3 = a.lerp(b, float(i) / float(n))
				for lane in LANES:
					if rng.randf() < SKIP_CHANCE:
						continue
					var off: float = float(lane) + rng.randf_range(-0.2, 0.2)
					var along: float = rng.randf_range(-0.2, 0.2)
					var x: float = base.x + perp.x * off + dir.x * along
					var z: float = base.z + perp.y * off + dir.y * along
					if absf(x + 40.0) < 3.4:
						continue    # овраг
					var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(Vector3(x, base.y + 3.0, z), Vector3(x, base.y - 5.0, z))
					q.collision_mask = 1
					var hit: Dictionary = space.intersect_ray(q)
					if hit.is_empty():
						continue
					var hp: Vector3 = hit["position"]
					var s: float = rng.randf_range(0.26, 0.42)
					var bs: Basis = Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s * rng.randf_range(0.85, 1.3), s * rng.randf_range(0.8, 1.2), s * rng.randf_range(0.85, 1.3)))
					xfs.append(Transform3D(bs, Vector3(x, hp.y - 0.03, z)))
					edges.append(clampf((absf(float(lane)) - 0.6) * 1.1, 0.0, 1.0))
	if xfs.is_empty():
		return
	var mm: MultiMesh = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_custom_data = true
	mm.mesh = _make_cobble_mesh()
	mm.instance_count = xfs.size()
	for i in xfs.size():
		mm.set_instance_transform(i, xfs[i])
		mm.set_instance_custom_data(i, Color(float(edges[i]), 0.0, 0.0, 0.0))
	var mmi: MultiMeshInstance3D = MultiMeshInstance3D.new()
	mmi.name = "CobbleTrail"
	mmi.multimesh = mm
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mmi.visibility_range_end = 110.0
	if ResourceLoader.exists(COBBLE_SHADER):
		var sm: ShaderMaterial = ShaderMaterial.new()
		sm.shader = load(COBBLE_SHADER) as Shader
		sm.render_priority = 1
		mmi.material_override = sm
	else:
		var fb: StandardMaterial3D = StandardMaterial3D.new()
		fb.albedo_color = Color(0.17, 0.18, 0.18)
		fb.roughness = 1.0
		mmi.material_override = fb
	add_child(mmi)
