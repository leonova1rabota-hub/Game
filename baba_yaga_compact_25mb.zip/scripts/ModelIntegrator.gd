extends Node3D
signal models_ready
## Автоподстановка 3D-моделей из res://assets/custom/models/ в мир игры.
## Роли определяются по имени файла (см. ModelLib.ROLE_KEYS). Если модели нет —
## остаётся процедурный объект, игра работает как раньше.

const ModelLib = preload("res://scripts/ModelLib.gd")
const ModelData = preload("res://scripts/ModelData.gd")
const NightLife = preload("res://scripts/NightLife.gd")
const Flags = preload("res://scripts/FeatureFlags.gd")

const TOWER_POS: Vector3 = Vector3(-78.0, 8.0, -24.0)    # поверхность плато холма y = 8
const TOWER_HEIGHT: float = 22.0
const WitchIdle = preload("res://scripts/WitchIdle.gd")
var islet_top_y: float = -100.0
const PathBuilder = preload("res://scripts/PathBuilder.gd")
const FIR_SHADER: String = "res://assets/fir_wind.gdshader"
const STAIR_CENTER_R: float = 5.6          # радиус каменной лестницы вокруг башни, м
const STEP_RISE: float = 0.25               # высота ступени
const STEP_RUN: float = 0.4                 # глубина ступени
const STEP_WIDTH: float = 1.8               # ширина ступени (внутренний край упирается в стену)
const RAMP_R: float = 5.6                   # средняя линия невидимого наклонного коллайдера (на всю ширину ступеней)
const RAMP_WIDTH: float = 1.8
const STAIR_START_DEG: float = -30.0       # низ лестницы — со стороны подхода (восток)
const ROOF_GAP_DEG: float = -83.0         # здесь парапет разрушен: заходим на смотровую площадку
const ROOF_Y_FALLBACK: float = 26.7
const SWAMP_CENTER: Vector3 = Vector3(-25.0, 0.0, 34.0)
const CAVE_B: Vector2 = Vector2(65.716, -5.152)    # точка на оси пола тоннеля (наклон -20°)
const CAVE_STEP_X0: float = 51.8
const CAVE_STEPS: int = 39
const WITCH_SKIN_SHADER: String = "res://assets/witch_skin.gdshader"
const WATER_SHADER: String = "res://assets/river_water.gdshader"

const TREE_SHADER: String = "res://assets/tree_sway.gdshader"
const TREE_CELL: float = 32.0
const TREE_LOD_DIST: float = 50.0
const TREE_FAR_DIST: float = 170.0

const HOUSE_POS: Vector3 = Vector3(2.0, 0.0, 46.0)
const HOUSE_YAW_DEG: float = 180.0
const HOUSE_HEIGHT: float = 6.0
const HOUSE_SINK: float = -0.22      # цокольная «дёрновая» часть модели уходит в землю

const CAULDRON_SCALE: float = 0.0125  # модель котла в сантиметрах
const WITCH_HEIGHT: float = 1.7
const CANDLE_HEIGHT: float = 1.7

var catalog: Dictionary = {}
var meta: Dictionary = {}
var tree_mat: ShaderMaterial = null
var flame_tex: GradientTexture2D = null

func _ready() -> void:
	add_to_group("world_finale")
	meta = ModelData.META
	catalog = ModelLib.scan()
	print("[ModelIntegrator] найдено ролей: ", catalog.keys())
	flame_tex = _make_glow_tex()
	# ждём, пока CSG-ландшафт построит физическую коллизию (нужна для привязки к земле)
	for i in 4:
		await get_tree().physics_frame
	_snap_props()
	_build_trees()
	_build_rocks()
	_build_axe()
	_build_tower()
	_build_chest()
	_build_mountains()
	if Flags.BIG_MOUNTAIN and catalog.has("big_mountain"):
		pass    # v12: монолитная гора строится в конце (нужны кадры физики для проверки прохода)
	elif Flags.MASSIF:
		_build_mountain_massif()
	if Flags.CAVE_ENTRANCE:
		_build_cave_entrance()
	if Flags.FIRS:
		_build_path_firs()
	if Flags.WITCH_ISLAND:
		_build_witch_island()
	_build_swamp_witch()
	if Flags.REEDS:
		_build_reeds()
	_build_swamp_water()
	_build_night_life()
	_build_house()
	_build_witch()
	_build_cauldron()
	_build_altar()
	_build_candles()
	# --- v12: скачанные модели
	if Flags.PINES:
		_build_pines()
	if Flags.BOOK_STAND:
		_build_book_props()
	if Flags.KEY_BOULDERS:
		_build_key_boulders()
	if Flags.HUT_MODEL:
		await _build_hut_model()
	if Flags.BIG_MOUNTAIN and catalog.has("big_mountain"):
		await _build_big_mountain()
	if Flags.SEA_CAVE:
		await _build_sea_cave()
	if Flags.HUT_FURNITURE:
		_build_v14_hut()
	if Flags.CAVE_WALL_MODEL:
		_build_v14_cave_wall()
	if Flags.CAVE_CRYSTALS:
		_build_v14_crystals()
	await _v16_fix_cleft()
	_purge_shards()
	models_ready.emit()

# ------------------------------------------------------------------ helpers
func _make_glow_tex() -> GradientTexture2D:
	var g: Gradient = Gradient.new()
	g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
	g.offsets = PackedFloat32Array([0.0, 1.0])
	var t: GradientTexture2D = GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	t.width = 64
	t.height = 64
	return t

func _glow_material(col: Color) -> StandardMaterial3D:
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = flame_tex
	m.albedo_color = col
	m.disable_receive_shadows = true
	return m

func _hide_csg(n: Node) -> void:
	if n == null:
		return
	# Полное удаление из дерева: скрытые CSG больше не пересчитываются и не рендерятся.
	if n is CSGShape3D:
		var c: CSGShape3D = n as CSGShape3D
		c.use_collision = false
		c.visible = false
		c.queue_free()
	elif n is Node3D:
		(n as Node3D).visible = false
		n.queue_free()

func _flicker(light: OmniLight3D, base: float) -> void:
	var tw: Tween = create_tween().set_loops()
	for i in 4:
		tw.tween_property(light, "light_energy", base * randf_range(0.7, 1.2), randf_range(0.08, 0.22))

func _add_flame(parent: Node3D, pos: Vector3, size: float) -> void:
	var q: QuadMesh = QuadMesh.new()
	q.size = Vector2(size, size * 1.6)
	q.material = _glow_material(Color(2.6, 1.3, 0.45, 1.0))
	var mi: MeshInstance3D = MeshInstance3D.new()
	mi.mesh = q
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	var tw: Tween = create_tween().set_loops()
	tw.tween_property(mi, "scale", Vector3(0.85, 1.15, 1.0), randf_range(0.12, 0.3))
	tw.tween_property(mi, "scale", Vector3(1.1, 0.9, 1.0), randf_range(0.12, 0.3))

func _sway(node: Node3D, deg: float, period: float) -> void:
	var tz: Tween = create_tween().set_loops()
	tz.tween_property(node, "rotation_degrees:z", deg, period).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tz.tween_property(node, "rotation_degrees:z", -deg, period).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var tx: Tween = create_tween().set_loops()
	tx.tween_property(node, "rotation_degrees:x", deg * 0.6, period * 1.37).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tx.tween_property(node, "rotation_degrees:x", -deg * 0.6, period * 1.37).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	# «дыхание» избы: лёгкое растяжение по высоте
	var tb: Tween = create_tween().set_loops()
	tb.tween_property(node, "scale", Vector3(1.0, 1.006, 1.0), period * 0.8).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tb.tween_property(node, "scale", Vector3(1.0, 0.996, 1.0), period * 0.8).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

# ------------------------------------------------------------------ привязка к ландшафту
func _ground_y(x: float, z: float, y_from: float, y_to: float) -> Variant:
	var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(Vector3(x, y_from, z), Vector3(x, y_to, z))
	q.collision_mask = 1
	var hit: Dictionary = space.intersect_ray(q)
	if hit.is_empty():
		return null
	var pos: Vector3 = hit["position"]
	return pos.y

## Объекты, рассчитанные на плоскую землю (y = 0), «сажаем» на реальный рельеф:
## болотные сухие деревья (Dead*) и всё, что оказалось в чаше болота.
func _snap_props() -> void:
	var root: Node = get_parent()
	var swamp: Node = root.get_node_or_null("Swamp")
	if swamp != null:
		for c in swamp.get_children():
			var nm: String = String(c.name)
			if not nm.begins_with("Dead") or not (c is Node3D):
				continue
			var idx: String = nm.substr(10) if nm.begins_with("DeadBranch") else nm.substr(4)
			var trunk: Node3D = swamp.get_node_or_null("Dead" + idx) as Node3D
			if trunk == null:
				continue
			var gy: Variant = _ground_y(trunk.position.x + 0.8, trunk.position.z, 8.0, -12.0)
			if gy != null and absf(float(gy)) > 0.15:
				(c as Node3D).position.y += float(gy)
	var forest: Node = root.get_node_or_null("Forest")
	if forest != null:
		for c2 in forest.get_children():
			var n2: String = String(c2.name)
			if not (n2.begins_with("Mu") or n2.begins_with("Log") or n2.begins_with("B")) or not (c2 is Node3D):
				continue
			var p3: Vector3 = (c2 as Node3D).position
			if Vector2(p3.x + 25.0, p3.z - 34.0).length() > 17.5:
				continue
			var g2: Variant = _ground_y(p3.x, p3.z, 6.0, -12.0)
			if g2 != null and absf(float(g2)) > 0.15:
				(c2 as Node3D).position.y += float(g2)

# ------------------------------------------------------------------ trees
func _build_trees() -> void:
	var paths: Array = catalog.get("tree", [])
	if paths.is_empty():
		return
	var meshes: Array = []
	if ResourceLoader.exists(TREE_SHADER):
		tree_mat = ShaderMaterial.new()
		tree_mat.shader = load(TREE_SHADER) as Shader
	for p in paths:
		var path: String = p
		var inst: Node3D = ModelLib.instance(path)
		if inst == null:
			continue
		var msh: Mesh = ModelLib.first_mesh(inst)
		if msh != null:
			var dup: Mesh = msh.duplicate() as Mesh
			if tree_mat != null:
				for s in dup.get_surface_count():
					dup.surface_set_material(s, tree_mat)
			meshes.append(dup)
		inst.queue_free()
	var tree_k: float = 1.0
	if Flags.FOREST_PINES:
		var pine_mesh: ArrayMesh = _v14_pine_mesh()
		if pine_mesh != null:
			meshes = [pine_mesh]
			tree_k = V14_PINE_K
			for fo in get_tree().get_nodes_in_group("forest_foliage"):
				fo.queue_free()    # старые сферы-кроны Forest (B#, B#x)
	if meshes.is_empty():
		return
	var spots: Array = []
	for sp0 in ModelData.TREE_SPOTS:
		var spot: Array = (sp0 as Array).duplicate()
		var gy: Variant = _ground_y(float(spot[0]), float(spot[2]), float(spot[1]) + 2.5, float(spot[1]) - 8.0)
		if gy == null:
			continue    # под деревом нет земли — не ставим «висящее» дерево
		spot[1] = float(gy) - 0.1    # v13: Y ствола = Y земли
		spots.append(spot)
	var cells: Dictionary = {}
	for i in spots.size():
		var sp: Array = spots[i]
		var key: Vector2i = Vector2i(floori(float(sp[0]) / TREE_CELL), floori(float(sp[2]) / TREE_CELL))
		if not cells.has(key):
			cells[key] = []
		var lst: Array = cells[key]
		lst.append(i)
	var root: Node3D = Node3D.new()
	root.name = "ModelTrees"
	add_child(root)
	var trunk_r: float = float(meta.get("dead_tree", {}).get("trunk_r", 0.065))
	var colliders: StaticBody3D = StaticBody3D.new()
	colliders.name = "TreeColliders"
	root.add_child(colliders)
	for key in cells:
		var arr: Array = cells[key]
		var k2: Vector2i = key
		var center: Vector3 = Vector3((k2.x + 0.5) * TREE_CELL, 0.0, (k2.y + 0.5) * TREE_CELL)
		for lod in meshes.size():
			var mm: MultiMesh = MultiMesh.new()
			mm.transform_format = MultiMesh.TRANSFORM_3D
			mm.mesh = meshes[lod]
			mm.instance_count = arr.size()
			for j in arr.size():
				var sp2: Array = spots[arr[j]]
				var h: float = float(sp2[4]) * tree_k
				var b: Basis = Basis(Vector3.UP, float(sp2[3])).scaled(Vector3(h, h, h))
				mm.set_instance_transform(j, Transform3D(b, Vector3(float(sp2[0]) - center.x, float(sp2[1]), float(sp2[2]) - center.z)))
			var mmi: MultiMeshInstance3D = MultiMeshInstance3D.new()
			mmi.multimesh = mm
			mmi.position = center
			mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			if meshes.size() > 1:
				if lod == 0:
					mmi.visibility_range_end = TREE_LOD_DIST
				else:
					mmi.visibility_range_begin = TREE_LOD_DIST
					mmi.visibility_range_end = TREE_FAR_DIST
			else:
				mmi.visibility_range_end = TREE_FAR_DIST
			root.add_child(mmi)
		for idx in arr:
			var sp3: Array = spots[idx]
			var hh: float = float(sp3[4])
			var cs: CollisionShape3D = CollisionShape3D.new()
			var cyl: CylinderShape3D = CylinderShape3D.new()
			cyl.radius = maxf(trunk_r * hh, 0.25)
			cyl.height = minf(hh * 0.6, 4.5)
			cs.shape = cyl
			cs.position = Vector3(float(sp3[0]), float(sp3[1]) + cyl.height * 0.5, float(sp3[2]))
			colliders.add_child(cs)

# ------------------------------------------------------------------ rocks (мшистые валуны вместо угловатых блоков)
func _build_rocks() -> void:
	var paths: Array = catalog.get("rock", [])
	var forest: Node = get_parent().get_node_or_null("Forest")
	if paths.is_empty() or forest == null:
		return
	var root: Node3D = Node3D.new()
	root.name = "ModelRocks"
	add_child(root)
	var k: int = 0
	for c in forest.get_children():
		var nm: String = String(c.name)
		if not (c is CSGBox3D) or not nm.begins_with("Rk"):
			continue
		var src: CSGBox3D = c as CSGBox3D
		var path: String = paths[k % paths.size()]
		k += 1
		var inst: Node3D = ModelLib.instance(path)
		if inst == null:
			continue
		var holder: Node3D = Node3D.new()
		holder.position = Vector3(src.position.x, 0.0, src.position.z)
		holder.rotation.y = src.rotation.y
		root.add_child(holder)
		holder.add_child(inst)
		var ab: AABB = ModelLib.model_aabb(path, inst, meta)
		var w: float = maxf(src.size.x, src.size.z) * 1.1
		var s: float = w / maxf(maxf(ab.size.x, ab.size.z), 0.0001)
		ModelLib.fit(inst, ab, 0.0, s, src.position.y - src.size.y * 0.5 - 0.05)
		ModelLib.add_convex_body(holder, inst)
		_hide_csg(src)
		var moss: Node = forest.get_node_or_null("Rm" + nm.substr(2))
		_hide_csg(moss)

# ------------------------------------------------------------------ axe (топор, воткнутый в пень)
func _build_axe() -> void:
	var paths: Array = catalog.get("axe", [])
	var axe: Node3D = get_parent().get_node_or_null("Shed/Axe") as Node3D
	if paths.is_empty() or axe == null:
		return
	var path: String = paths[0]
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	_hide_csg(axe.get_node_or_null("Handle"))
	_hide_csg(axe.get_node_or_null("Blade"))
	axe.add_child(inst)
	# Модель: рукоять вдоль +Y, режущая кромка на +X. Поворот на -108° вокруг Z:
	# кромка смотрит вниз (с наклоном 18°), рукоять приподнята на 18° над горизонталью.
	var ed: Array = meta.get("axe", {}).get("edge", [1.36, 3.154, 0.0])
	var edge: Vector3 = Vector3(float(ed[0]), float(ed[1]), float(ed[2]))
	var s: float = 0.157
	var axe_basis: Basis = Basis(Vector3.UP, deg_to_rad(20.0)) * Basis(Vector3(0.0, 0.0, 1.0), deg_to_rad(-108.0)) * Basis.from_scale(Vector3(s, s, s))
	# верх пня в локальных координатах узла топора: y = -0.3; лезвие врублено на 12 см вглубь
	var target: Vector3 = Vector3(0.0, -0.3 - 0.12, 0.0)
	inst.transform = Transform3D(axe_basis, target - axe_basis * edge)

# ------------------------------------------------------------------ house
func _build_house() -> void:
	var paths: Array = catalog.get("house", [])
	if paths.is_empty():
		return
	var path: String = paths[0]
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	var holder: Node3D = Node3D.new()
	holder.name = "WitchCottage"
	holder.position = HOUSE_POS
	holder.rotation_degrees = Vector3(0.0, HOUSE_YAW_DEG, 0.0)
	add_child(holder)
	var pivot: Node3D = Node3D.new()
	pivot.name = "SwayPivot"
	holder.add_child(pivot)
	pivot.add_child(inst)
	var ab: AABB = ModelLib.model_aabb(path, inst, meta)
	ModelLib.fit(inst, ab, HOUSE_HEIGHT, 0.0, HOUSE_SINK)
	ModelLib.add_trimesh_body(holder, inst)    # коллизия не качается вместе с визуалом
	var lamp: OmniLight3D = OmniLight3D.new()
	lamp.light_color = Color(1.0, 0.62, 0.28)
	lamp.light_energy = 1.4
	lamp.omni_range = 9.0
	lamp.position = Vector3(0.0, 2.2, 3.4)
	holder.add_child(lamp)
	_flicker(lamp, 1.4)
	_sway(pivot, 0.28, 3.2)

# ------------------------------------------------------------------ witch (Баба Яга)
func _build_witch() -> void:
	var paths: Array = catalog.get("witch", [])
	var yaga: Node3D = get_parent().get_node_or_null("YagaRoot/YagaModel") as Node3D
	if paths.is_empty() or yaga == null:
		return
	var path: String = paths[0]
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	for c in yaga.get_children():
		if c is CSGShape3D:
			_hide_csg(c)
	var chair: Node = get_parent().get_node_or_null("YagaRoot/Chair")
	if chair != null:
		for c2 in chair.get_children():
			_hide_csg(c2)
	yaga.add_child(inst)
	var ab: AABB = ModelLib.model_aabb(path, inst, meta)
	ModelLib.fit(inst, ab, WITCH_HEIGHT, 0.0, 0.02)
	var ap: AnimationPlayer = ModelLib.find_anim_player(inst)
	if ap != null:
		var names: PackedStringArray = ap.get_animation_list()
		if names.size() > 0:
			var anim: Animation = ap.get_animation(names[0])
			if anim != null:
				anim.loop_mode = Animation.LOOP_LINEAR
			ap.play(names[0])

# ------------------------------------------------------------------ cauldron
func _build_cauldron() -> void:
	var paths: Array = catalog.get("cauldron", [])
	var cauldron: Node3D = get_parent().get_node_or_null("Cauldron") as Node3D
	if paths.is_empty() or cauldron == null:
		return
	var path: String = paths[0]
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	# скрыть процедурный котёл, оставить интерактивные тела и жидкость
	for nm in ["StoneRing", "Leg0", "Leg1", "Leg2"]:
		_hide_csg(cauldron.get_node_or_null(nm))
	var pot: Node3D = cauldron.get_node_or_null("Pot") as Node3D
	var fire: Node3D = cauldron.get_node_or_null("Fire") as Node3D
	if pot != null:
		for c in pot.get_children():
			if c is CSGShape3D:
				_hide_csg(c)
	if fire != null:
		for nm2 in ["LogA", "LogB"]:
			_hide_csg(fire.get_node_or_null(nm2))
	cauldron.add_child(inst)
	var ab: AABB = ModelLib.model_aabb(path, inst, meta)
	var s: float = ModelLib.fit(inst, ab, 0.0, CAULDRON_SCALE, 0.0)
	# родная жидкость модели скрывается: цветом зелья управляет игра
	var meshes: Array = []
	ModelLib.collect_meshes(inst, meshes)
	for m in meshes:
		var mi: MeshInstance3D = m
		if String(mi.name).to_lower().find("liquid") != -1 or String(mi.get_parent().name).to_lower().find("liquid") != -1:
			mi.visible = false
	var liquid_y: float = (69.3 - ab.position.y) * s
	var liquid: CSGCylinder3D = cauldron.get_node_or_null("Liquid") as CSGCylinder3D
	if liquid != null:
		liquid.radius = 0.34
		liquid.position.y = liquid_y
	var wc: Node = get_parent()
	if "liquid_y" in wc:
		wc.set("liquid_y", liquid_y)
	var light: Node3D = cauldron.get_node_or_null("CauldronLight") as Node3D
	if light != null:
		light.position.y = liquid_y + 0.8
	# коллизии под реальный размер модели
	if pot != null:
		var shp: CollisionShape3D = pot.get_node_or_null("Shape") as CollisionShape3D
		if shp != null:
			var cyl: CylinderShape3D = CylinderShape3D.new()
			cyl.radius = 0.62
			cyl.height = 0.6
			shp.shape = cyl
		pot.position.y = 0.75
	if fire != null:
		fire.position.y = 0.2
	_add_potion_particles(cauldron, liquid_y)

func _add_potion_particles(parent: Node3D, y: float) -> void:
	# пузырьки зелья
	parent.add_child(_make_particles(y + 0.04, 34, 2.6, 0.3, 0.3, 0.8, 0.13, Color(0.55, 2.2, 0.8, 1.0), 0.0))
	# лёгкий зелёный пар/мерцание
	parent.add_child(_make_particles(y + 0.1, 12, 3.8, 0.28, 0.15, 0.4, 0.55, Color(0.25, 0.9, 0.4, 0.35), 0.0))

func _make_particles(y: float, amount: int, life: float, emit_r: float, vmin: float, vmax: float, quad: float, col: Color, grav_y: float) -> GPUParticles3D:
	var p: GPUParticles3D = GPUParticles3D.new()
	p.position = Vector3(0.0, y, 0.0)
	p.amount = amount
	p.lifetime = life
	p.preprocess = life
	p.visibility_aabb = AABB(Vector3(-1.5, -1.0, -1.5), Vector3(3.0, 4.0, 3.0))
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var pm: ParticleProcessMaterial = ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = emit_r
	pm.direction = Vector3(0.0, 1.0, 0.0)
	pm.spread = 14.0
	pm.initial_velocity_min = vmin
	pm.initial_velocity_max = vmax
	pm.gravity = Vector3(0.0, grav_y, 0.0)
	pm.scale_min = 0.5
	pm.scale_max = 1.3
	var g: Gradient = Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.2, 0.75, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 1), Color(1, 1, 1, 0.7), Color(1, 1, 1, 0)])
	var gt: GradientTexture1D = GradientTexture1D.new()
	gt.gradient = g
	pm.color_ramp = gt
	p.process_material = pm
	var q: QuadMesh = QuadMesh.new()
	q.size = Vector2(quad, quad)
	q.material = _glow_material(col)
	p.draw_pass_1 = q
	p.emitting = true
	return p

# ------------------------------------------------------------------ altar (саркофаг-алтарь в гроте)
func _build_altar() -> void:
	var paths: Array = catalog.get("altar", [])
	if paths.is_empty():
		return
	var path: String = paths[0]
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	var holder: Node3D = Node3D.new()
	holder.name = "RitualAltar"
	holder.position = Vector3(92.0, -10.6, 10.6)
	holder.rotation_degrees = Vector3(0.0, 180.0, 0.0)
	add_child(holder)
	holder.add_child(inst)
	var ab: AABB = ModelLib.model_aabb(path, inst, meta)
	var s: float = ModelLib.fit(inst, ab, 1.25, 0.0, 0.0)
	var body: StaticBody3D = StaticBody3D.new()
	var cs: CollisionShape3D = CollisionShape3D.new()
	var box: BoxShape3D = BoxShape3D.new()
	box.size = ab.size * s
	cs.shape = box
	cs.position = Vector3(0.0, box.size.y * 0.5, 0.0)
	body.add_child(cs)
	holder.add_child(body)
	var fl: Array = meta.get("ritual_altar", {}).get("flames", [])
	for f in fl:
		var fp: Array = f
		_add_flame(holder, Vector3(float(fp[0]), float(fp[1]), float(fp[2])) * 1.25 + Vector3(0.0, 0.1, 0.0), 0.12)
	var light: OmniLight3D = OmniLight3D.new()
	light.light_color = Color(1.0, 0.6, 0.25)
	light.light_energy = 1.1
	light.omni_range = 6.0
	light.position = Vector3(0.0, 2.0, 0.0)
	holder.add_child(light)
	_flicker(light, 1.1)

# ------------------------------------------------------------------ candle holders
func _build_candles() -> void:
	var paths: Array = catalog.get("candle", [])
	if paths.is_empty():
		return
	var path: String = paths[0]
	var spots: Array = [
		Vector3(-2.2, 0.02, 6.4), Vector3(2.2, 0.02, 6.4),     # вход в избу
		Vector3(89.2, -10.6, 2.4), Vector3(89.2, -10.6, 7.6),   # грот у алтаря
	]
	var lit_lights: int = 0
	for i in spots.size():
		var inst: Node3D = ModelLib.instance(path)
		if inst == null:
			return
		var holder: Node3D = Node3D.new()
		holder.name = "CandleHolder%d" % i
		holder.position = spots[i]
		add_child(holder)
		holder.add_child(inst)
		var ab: AABB = ModelLib.model_aabb(path, inst, meta)
		ModelLib.fit(inst, ab, CANDLE_HEIGHT, 0.0, 0.0)
		ModelLib.add_cylinder_body(holder, Vector3.ZERO, 0.16, CANDLE_HEIGHT)
		var fl: Array = meta.get("candle_holder", {}).get("flames", [])
		for f in fl:
			var fp: Array = f
			_add_flame(holder, Vector3(float(fp[0]), float(fp[1]), float(fp[2])) * CANDLE_HEIGHT + Vector3(0.0, 0.07, 0.0), 0.09)
		if lit_lights < 4:
			var lt: OmniLight3D = OmniLight3D.new()
			lt.light_color = Color(1.0, 0.65, 0.3)
			lt.light_energy = 0.9
			lt.omni_range = 5.0
			lt.position = Vector3(0.0, CANDLE_HEIGHT + 0.15, 0.0)
			holder.add_child(lt)
			_flicker(lt, 0.9)
			lit_lights += 1

# ------------------------------------------------------------------ финал
func on_finale(duration: float) -> void:
	for pm in pine_mats:
		create_tween().tween_property(pm, "albedo_color", Color(1.0, 1.0, 0.92), duration)
	if tree_mat != null:
		var tw: Tween = create_tween()
		tw.tween_method(func(v: float) -> void: tree_mat.set_shader_parameter("tint", Color(0.52, 0.52, 0.66).lerp(Color(1.05, 1.0, 0.8), v)), 0.0, 1.0, duration)


# ================================================================== v6: объединённые модели
func _hide_render(n: Node) -> void:
	# убрать только картинку, физика CSG остаётся
	if n is GeometryInstance3D:
		(n as GeometryInstance3D).layers = 0

func _find_child_node(root: Node, node_name: String) -> Node3D:
	return root.find_child(node_name, true, false) as Node3D

func _vertex_color_material(rough: float, tint: Color) -> StandardMaterial3D:
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.albedo_color = tint
	mat.roughness = rough
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	return mat

func _wood_mat(c: Color) -> StandardMaterial3D:
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = c
	mat.roughness = 0.95
	return mat

func _build_night_life() -> void:
	var nl: Node3D = NightLife.new()
	nl.name = "NightLife"
	get_parent().add_child(nl)

func _build_tower() -> void:
	var paths: Array = catalog.get("tower", [])
	var tower: Node3D = get_parent().get_node_or_null("Tower") as Node3D
	if paths.is_empty() or tower == null:
		return
	var inst: Node3D = ModelLib.instance(paths[0])
	if inst == null:
		return
	for c in tower.get_children():
		if c is CSGShape3D:
			_hide_csg(c)
	var holder: Node3D = Node3D.new()
	holder.name = "TowerModel"
	holder.position = TOWER_POS
	get_parent().add_child(holder)
	holder.add_child(inst)
	var ab: AABB = ModelLib.mesh_aabb(inst)
	ModelLib.fit(inst, ab, TOWER_HEIGHT, 0.0, -0.3)
	ModelLib.add_trimesh_body(holder, inst)   # стены и перекрытия башни: точная коллизия по мешу
	var lt: Node3D = tower.get_node_or_null("TowerLight") as Node3D
	if lt != null:
		lt.position = Vector3(TOWER_POS.x, TOWER_POS.y + 9.0, TOWER_POS.z)
	# Ждём, пока коллизия башни попадёт в физический мир, и находим настоящую высоту крыши лучом.
	await get_tree().physics_frame
	await get_tree().physics_frame
	await get_tree().physics_frame
	var gap_rad: float = deg_to_rad(ROOF_GAP_DEG)
	var chest_xz: Vector2 = Vector2(TOWER_POS.x + cos(gap_rad) * 2.0, TOWER_POS.z + sin(gap_rad) * 2.0)
	var roof_y: float = ROOF_Y_FALLBACK
	var ry: Variant = _ground_y(chest_xz.x, chest_xz.y, TOWER_POS.y + TOWER_HEIGHT + 6.0, TOWER_POS.y + 6.0)
	if ry != null:
		roof_y = float(ry)
	if Flags.TOWER_STAIRS:
		_build_tower_stairs(roof_y)
	# сундук — на верхней смотровой площадке
	var chest: Node3D = get_parent().get_node_or_null("Tower/Chest") as Node3D
	if chest != null:
		chest.position = Vector3(chest_xz.x, roof_y + 0.4, chest_xz.y)

func _build_chest() -> void:
	var paths: Array = catalog.get("chest", [])
	var chest: Node3D = get_parent().get_node_or_null("Tower/Chest") as Node3D
	if paths.is_empty() or chest == null:
		return
	var inst: Node3D = ModelLib.instance(paths[0])
	if inst == null:
		return
	var pivot: Node3D = chest.get_node_or_null("LidPivot") as Node3D
	for nm in ["Body", "Band"]:
		_hide_csg(chest.get_node_or_null(nm))
	if pivot != null:
		_hide_csg(pivot.get_node_or_null("Lid"))
	chest.rotation_degrees = Vector3(0.0, 70.0, 0.0)
	var body_mesh: Node3D = _find_child_node(inst, "ChestBody")
	var lid_mesh: Node3D = _find_child_node(inst, "ChestLid")
	if body_mesh != null:
		body_mesh.owner = null
		body_mesh.reparent(chest, false)
	if lid_mesh != null and pivot != null:
		lid_mesh.owner = null
		lid_mesh.reparent(pivot, false)
	inst.queue_free()

func _build_mountains() -> void:
	var paths: Array = catalog.get("mountain", [])
	var mroot: Node3D = get_parent().get_node_or_null("Mountains") as Node3D
	if paths.is_empty() or mroot == null:
		return
	var probe: Node3D = ModelLib.instance(paths[0])
	if probe == null:
		return
	var msh: Mesh = ModelLib.first_mesh(probe)
	probe.queue_free()
	if msh == null:
		return
	var ab: AABB = msh.get_aabb()
	var boxes: Array = []
	for c in mroot.get_children():
		if c is CSGBox3D:
			boxes.append(c)
	if boxes.is_empty():
		return
	var mm: MultiMesh = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = msh
	mm.instance_count = boxes.size()
	for i in boxes.size():
		var b: CSGBox3D = boxes[i]
		var wide: float = maxf(b.size.x, b.size.z) * 1.9
		var sx: float = wide / maxf(ab.size.x, 0.001)
		var sz: float = wide / maxf(ab.size.z, 0.001)
		var sy: float = (b.size.y * 1.35 + 2.0) / maxf(ab.size.y, 0.001)
		var bs: Basis = Basis(Vector3.UP, b.rotation.y).scaled(Vector3(sx, sy, sz))
		var base_y: float = b.position.y - b.size.y * 0.5 - 1.0 - ab.position.y * sy
		mm.set_instance_transform(i, Transform3D(bs, Vector3(b.position.x, base_y, b.position.z)))
		_hide_render(b)
	var mmi: MultiMeshInstance3D = MultiMeshInstance3D.new()
	mmi.name = "MountainRocks"
	mmi.material_override = _vertex_color_material(1.0, Color(0.55, 0.58, 0.65))    # тёмные скальные стены по периметру
	mmi.multimesh = mm
	mmi.custom_aabb = AABB(Vector3(-260, -20, -260), Vector3(520, 120, 520))
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mmi)

func _build_swamp_witch() -> void:
	var paths: Array = catalog.get("swamp_witch", [])
	var witch: Node3D = get_parent().get_node_or_null("Swamp/Witch") as Node3D
	if paths.is_empty() or witch == null:
		return
	var inst: Node3D = ModelLib.instance(paths[0])
	if inst == null:
		return
	for c in witch.get_children():
		if c is CSGShape3D:
			_hide_csg(c)
	# Ноги — ровно на верхней грани камня-рифа: Y ведьмы = Y верха камня
	var top_y: float = islet_top_y
	if top_y < -50.0:
		top_y = witch.global_position.y
	var holder: Node3D = WitchIdle.new()
	holder.name = "WitchModel"
	witch.add_child(holder)
	holder.position = Vector3(0.0, top_y - witch.global_position.y, 0.0)
	holder.add_child(inst)
	var ab: AABB = ModelLib.mesh_aabb(inst)
	ModelLib.fit(inst, ab, 2.1, 0.0, 0.0)
	if ResourceLoader.exists(WITCH_SKIN_SHADER):
		var sm: ShaderMaterial = ShaderMaterial.new()
		sm.shader = load(WITCH_SKIN_SHADER) as Shader
		var meshes: Array = []
		ModelLib.collect_meshes(inst, meshes)
		for n in meshes:
			(n as MeshInstance3D).material_override = sm

func _angle_gap(a: float, b: float) -> float:
	return absf(wrapf(a - b, -PI, PI))

func _build_reeds() -> void:
	var paths: Array = catalog.get("reeds", [])
	var swamp: Node3D = get_parent().get_node_or_null("Swamp") as Node3D
	if paths.is_empty() or swamp == null:
		return
	var probe: Node3D = ModelLib.instance(paths[0])
	if probe == null:
		return
	var msh: Mesh = ModelLib.first_mesh(probe)
	probe.queue_free()
	if msh == null:
		return
	for c in swamp.get_children():
		if c is CSGCylinder3D and String(c.name).begins_with("Reed"):
			_hide_csg(c)
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 6061
	var spots: Array = []
	# Пучки по берегу с разрывами; сектор у восточной рампы (угол 0) и участок у ведьмы свободны.
	var clusters: int = 12
	for k in clusters:
		var ang: float = TAU * float(k) / float(clusters) + rng.randf_range(-0.18, 0.18)
		if _angle_gap(ang, 0.0) < 0.75:
			continue
		if rng.randf() < 0.3:
			continue
		var r: float = rng.randf_range(10.4, 11.6)
		var cc: Vector2 = Vector2(SWAMP_CENTER.x + cos(ang) * r, SWAMP_CENTER.z + sin(ang) * r)
		var n: int = rng.randi_range(4, 7)
		for j in n:
			var a2: float = rng.randf() * TAU
			var d2: float = rng.randf_range(0.0, 0.9)
			spots.append(Vector2(cc.x + cos(a2) * d2, cc.y + sin(a2) * d2))
	if spots.is_empty():
		return
	var mm: MultiMesh = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = msh
	mm.instance_count = spots.size()
	for i in spots.size():
		var sp: Vector2 = spots[i]
		var gy: Variant = _ground_y(sp.x, sp.y, 8.0, -8.0)
		var y: float = -2.55
		if gy != null:
			y = float(gy)
		var s: float = rng.randf_range(0.8, 1.3)
		var b: Basis = Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s, s * rng.randf_range(0.9, 1.25), s))
		mm.set_instance_transform(i, Transform3D(b, Vector3(sp.x, y - 0.05, sp.y)))
	var mmi: MultiMeshInstance3D = MultiMeshInstance3D.new()
	mmi.name = "SwampReeds"
	mmi.material_override = _vertex_color_material(0.9, Color(1, 1, 1))    # стебли #243D18, шишки #3B2211 (цвет в вершинах)
	mmi.multimesh = mm
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mmi)

func _build_swamp_water() -> void:
	var water: CSGCylinder3D = get_parent().get_node_or_null("Swamp/Water") as CSGCylinder3D
	if water == null or not ResourceLoader.exists(WATER_SHADER):
		return
	var m: ShaderMaterial = ShaderMaterial.new()
	m.shader = load(WATER_SHADER) as Shader
	m.set_shader_parameter("mode", 1)
	m.set_shader_parameter("lake_center", Vector2(water.position.x, water.position.z))
	m.set_shader_parameter("lake_radius", water.radius)
	m.set_shader_parameter("flow_vec", Vector2(0.05, 0.05))
	water.material = m

func _make_fir_mesh() -> ArrayMesh:
	var st: SurfaceTool = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var sides: int = 8
	var tiers: Array = [[1.9, 0.9, 2.6, 0.06], [1.55, 2.0, 3.8, 0.1], [1.2, 3.2, 5.0, 0.14], [0.85, 4.3, 6.1, 0.18], [0.5, 5.3, 7.0, 0.22]]
	for t in tiers:
		var rad: float = float(t[0])
		var y0: float = float(t[1])
		var y1: float = float(t[2])
		var shade: float = float(t[3])
		var base_col: Color = Color(0.035 + shade * 0.1, 0.1 + shade * 0.25, 0.06 + shade * 0.08)
		for s in sides:
			var a0: float = TAU * float(s) / float(sides)
			var a1: float = TAU * float(s + 1) / float(sides)
			var p0: Vector3 = Vector3(cos(a0) * rad, y0, sin(a0) * rad)
			var p1: Vector3 = Vector3(cos(a1) * rad, y0, sin(a1) * rad)
			var ap: Vector3 = Vector3(0.0, y1, 0.0)
			st.set_color(base_col * 0.7)
			st.add_vertex(p1)
			st.set_color(base_col * 0.7)
			st.add_vertex(p0)
			st.set_color(base_col * 1.15)
			st.add_vertex(ap)
	# ствол
	for s in 6:
		var a0: float = TAU * float(s) / 6.0
		var a1: float = TAU * float(s + 1) / 6.0
		var q0: Vector3 = Vector3(cos(a0) * 0.22, 0.0, sin(a0) * 0.22)
		var q1: Vector3 = Vector3(cos(a1) * 0.22, 0.0, sin(a1) * 0.22)
		var t0: Vector3 = Vector3(q0.x, 1.4, q0.z)
		var t1: Vector3 = Vector3(q1.x, 1.4, q1.z)
		var tc: Color = Color(0.1, 0.07, 0.04)
		st.set_color(tc)
		st.add_vertex(q1)
		st.add_vertex(q0)
		st.add_vertex(t0)
		st.add_vertex(q1)
		st.add_vertex(t0)
		st.add_vertex(t1)
	st.generate_normals()
	return st.commit()

func _near_any(p: Vector2, pts: Array, d: float) -> bool:
	for q in pts:
		if p.distance_to(q) < d:
			return true
	return false

## Густой ельник вдоль троп: MultiMesh с вертексным шейдером ветра (fir_wind.gdshader).
func _build_path_firs() -> void:
	var samples: Array = []
	for trail in PathBuilder.TRAILS:
		var pts: Array = trail
		for k in range(pts.size() - 1):
			var a: Vector2 = Vector2(float(pts[k][0]), float(pts[k][2]))
			var b: Vector2 = Vector2(float(pts[k + 1][0]), float(pts[k + 1][2]))
			var steps: int = maxi(1, int(a.distance_to(b) / 2.5))
			for s in steps:
				samples.append(a.lerp(b, float(s) / float(steps)))
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 7777
	var spots: Array = []
	for i in samples.size():
		if i % 2 != 0:
			continue
		var base: Vector2 = samples[i]
		for side in [-1.0, 1.0]:
			if rng.randf() < 0.25:
				continue
			var off: float = rng.randf_range(3.4, 8.5)
			var ang: float = rng.randf_range(0.0, TAU)
			var p: Vector2 = base + Vector2(cos(ang), sin(ang)) * off * 0.35 + Vector2(side * off, rng.randf_range(-1.5, 1.5)) * 0.9
			if _near_any(p, samples, 3.0) or p.length() < 11.0:
				continue
			if absf(p.x + 40.0) < 6.0 or p.distance_to(Vector2(-25.0, 34.0)) < 14.0 or p.distance_to(Vector2(-78.0, -24.0)) < 13.0:
				continue
			if p.x > 46.0 or absf(p.x) > 150.0 or absf(p.y) > 150.0:
				continue
			var gy: Variant = _ground_y(p.x, p.y, 40.0, -6.0)
			if gy == null:
				continue
			spots.append(Vector3(p.x, float(gy) - 0.12, p.y))
	if spots.is_empty():
		return
	var mm: MultiMesh = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = _make_fir_mesh()
	mm.instance_count = spots.size()
	var colliders: StaticBody3D = StaticBody3D.new()
	colliders.name = "FirColliders"
	for i in spots.size():
		var sp: Vector3 = spots[i]
		var s: float = rng.randf_range(0.95, 1.6)
		var b: Basis = Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s, s * rng.randf_range(0.95, 1.25), s))
		mm.set_instance_transform(i, Transform3D(b, sp))
		var cs: CollisionShape3D = CollisionShape3D.new()
		var cyl: CylinderShape3D = CylinderShape3D.new()
		cyl.radius = 0.3 * s
		cyl.height = 3.0
		cs.shape = cyl
		cs.position = sp + Vector3(0.0, 1.5, 0.0)
		colliders.add_child(cs)
	var mmi: MultiMeshInstance3D = MultiMeshInstance3D.new()
	mmi.name = "PathFirs"
	mmi.multimesh = mm
	if ResourceLoader.exists(FIR_SHADER):
		var sm: ShaderMaterial = ShaderMaterial.new()
		sm.shader = load(FIR_SHADER) as Shader
		mmi.material_override = sm
	else:
		mmi.material_override = _vertex_color_material(0.95, Color(1, 1, 1))
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mmi.visibility_range_end = 150.0
	add_child(mmi)
	add_child(colliders)

# ================================================================== v8
func _stone_mat(c: Color) -> StandardMaterial3D:
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = c
	mat.roughness = 1.0
	return mat

func _noise3(p: Vector3) -> float:
	return clampf(sin(p.x * 2.3 + 1.7) * cos(p.z * 2.9 - 0.4) * 0.6 + sin(p.y * 3.7 + p.x * 1.3) * 0.4 + sin(p.z * 5.1 + p.y * 2.2) * 0.2, -1.0, 1.0)

func _add_static_box(body: StaticBody3D, xf: Transform3D, size: Vector3, mat: Material, with_mesh: bool = true, with_collision: bool = true) -> void:
	if with_collision:
		var cs: CollisionShape3D = CollisionShape3D.new()
		var bx: BoxShape3D = BoxShape3D.new()
		bx.size = size
		cs.shape = bx
		cs.transform = xf
		body.add_child(cs)
	if with_mesh:
		var mi: MeshInstance3D = MeshInstance3D.new()
		var bm: BoxMesh = BoxMesh.new()
		bm.size = size
		mi.mesh = bm
		mi.material_override = mat
		mi.transform = xf
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		body.add_child(mi)

## Каменная лестница вокруг башни: ступени 0.25 x 0.4 м, у каждой BoxShape3D. Поверх — невидимый
## наклонный коллайдер по линии носиков ступеней (капсула радиусом 0.35 м не упирается в подступенки).
func _build_tower_stairs(roof_y: float) -> void:
	var body: StaticBody3D = StaticBody3D.new()
	body.name = "TowerStairs"
	body.collision_layer = 1
	body.collision_mask = 0
	get_parent().add_child(body)
	var cx: float = TOWER_POS.x
	var cz: float = TOWER_POS.z
	var y0: float = TOWER_POS.y + 0.02
	var n: int = maxi(8, roundi((roof_y - y0) / STEP_RISE))
	var rise: float = (roof_y - y0) / float(n)
	var dth: float = STEP_RUN / STAIR_CENTER_R
	var th0: float = deg_to_rad(STAIR_START_DEG)
	var stone_a: StandardMaterial3D = _stone_mat(Color(0.30, 0.30, 0.31))
	var stone_b: StandardMaterial3D = _stone_mat(Color(0.24, 0.25, 0.25))
	var rail_m: StandardMaterial3D = _stone_mat(Color(0.18, 0.19, 0.19))
	for i in n:
		var ang: float = th0 + (float(i) + 0.5) * dth
		var radial: Vector3 = Vector3(cos(ang), 0.0, sin(ang))
		var tangent: Vector3 = Vector3(-sin(ang), 0.0, cos(ang))
		var bs: Basis = Basis(tangent, Vector3.UP, -radial)
		var top_y: float = y0 + rise * float(i)
		var c: Vector3 = Vector3(cx + radial.x * STAIR_CENTER_R, top_y - 0.25, cz + radial.z * STAIR_CENTER_R)
		_add_static_box(body, Transform3D(bs, c), Vector3(STEP_RUN + 0.06, 0.5, STEP_WIDTH), stone_a if i % 2 == 0 else stone_b, true, false)
		if i % 12 == 6:
			var base_y: float = TOWER_POS.y - 0.3
			var h: float = (top_y - 0.5) - base_y
			if h > 0.5:
				var pc: Vector3 = Vector3(cx + radial.x * (STAIR_CENTER_R + 0.7), base_y + h * 0.5, cz + radial.z * (STAIR_CENTER_R + 0.7))
				_add_static_box(body, Transform3D(bs, pc), Vector3(0.6, h, 0.6), rail_m, true, false)
	# невидимый наклонный коллайдер + перила
	for k in n:
		var aa: float = th0 + float(k) * dth
		var ab2: float = th0 + float(k + 1) * dth
		var pa: Vector3 = Vector3(cx + cos(aa) * RAMP_R, y0 + rise * float(k), cz + sin(aa) * RAMP_R)
		var pb: Vector3 = Vector3(cx + cos(ab2) * RAMP_R, y0 + rise * float(k + 1), cz + sin(ab2) * RAMP_R)
		var mid: Vector3 = (pa + pb) * 0.5
		var dir: Vector3 = (pb - pa).normalized()
		var radial2: Vector3 = Vector3(mid.x - cx, 0.0, mid.z - cz).normalized()
		var zax: Vector3 = -radial2
		var yax: Vector3 = zax.cross(dir).normalized()
		var rbs: Basis = Basis(dir, yax, zax)
		var seg_len: float = pa.distance_to(pb) * 1.15
		_add_static_box(body, Transform3D(rbs, mid - yax * 0.25), Vector3(seg_len, 0.3, RAMP_WIDTH), null, false)
		if k < n - 4:
			var rail_pos: Vector3 = mid + radial2 * (RAMP_WIDTH * 0.5 + 0.05) + yax * 0.55
			_add_static_box(body, Transform3D(rbs, rail_pos), Vector3(seg_len, 1.1, 0.1), rail_m, false)
			if k % 2 == 0:
				var rm: MeshInstance3D = MeshInstance3D.new()
				var rbm: BoxMesh = BoxMesh.new()
				rbm.size = Vector3(seg_len * 2.0, 0.1, 0.1)
				rm.mesh = rbm
				rm.material_override = rail_m
				rm.transform = Transform3D(rbs, rail_pos + yax * 0.5)
				rm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				body.add_child(rm)
	# площадка на уровне крыши
	var ang_end: float = th0 + float(n) * dth
	var radial_end: Vector3 = Vector3(cos(ang_end), 0.0, sin(ang_end))
	var tang_end: Vector3 = Vector3(-sin(ang_end), 0.0, cos(ang_end))
	var plat_c: Vector3 = Vector3(cx, roof_y - 0.15, cz) + radial_end * 4.6
	_add_static_box(body, Transform3D(Basis(tang_end, Vector3.UP, -radial_end), plat_c), Vector3(2.2, 0.3, 3.0), stone_a)

## Грубый камень: деформированная сфера с «уступами». Грани плоские, цвет по нормали (мох сверху).
## flat_top < 1 срезает верх в горизонтальную площадку; terrace > 0 делает террасы.
func _rock_mesh(seed_v: float, rx: float, ry: float, rz: float, flat_top: float, terrace: float) -> ArrayMesh:
	var st: SurfaceTool = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_smooth_group(-1)
	var segs: int = 10
	var rings: int = 7
	var grid: Array = []
	for r in range(rings + 1):
		var phi: float = PI * float(r) / float(rings)
		var row: Array = []
		for s in segs:
			var th: float = TAU * float(s) / float(segs)
			var dir: Vector3 = Vector3(sin(phi) * cos(th), cos(phi), sin(phi) * sin(th))
			var nz: float = _noise3(dir * 2.2 + Vector3(seed_v, seed_v * 0.7, seed_v * 1.3))
			var k: float = 1.0 + 0.30 * nz
			var p: Vector3 = Vector3(dir.x * rx * k, dir.y * ry * (1.0 + 0.15 * nz), dir.z * rz * k)
			if p.y > ry * flat_top:
				p.y = ry * flat_top
			if terrace > 0.0:
				p.y = lerpf(p.y, roundf(p.y / terrace) * terrace, 0.6)
			row.append(p)
		grid.append(row)
	var rock_c: Color = Color(0.16, 0.165, 0.18)
	var moss_c: Color = Color(0.11, 0.22, 0.09)
	for r in rings:
		for s in segs:
			var s2: int = (s + 1) % segs
			var a: Vector3 = grid[r][s]
			var b: Vector3 = grid[r][s2]
			var c: Vector3 = grid[r + 1][s]
			var d: Vector3 = grid[r + 1][s2]
			for tri in [[a, c, b], [b, c, d]]:
				var t0: Vector3 = tri[0]
				var t1: Vector3 = tri[1]
				var t2: Vector3 = tri[2]
				var fn: Vector3 = (t2 - t0).cross(t1 - t0)
				if fn.length() < 0.00001:
					continue
				fn = fn.normalized()
				var moss: float = clampf((fn.y - 0.3) * 1.6 + 0.3 * _noise3(t0 * 0.8), 0.0, 1.0)
				var col: Color = rock_c.lerp(moss_c, moss * 0.85) * (0.85 + 0.3 * _noise3(t1 * 1.7 + Vector3(1.0, 2.0, 3.0)))
				col.a = 1.0
				for v in tri:
					st.set_color(col)
					st.add_vertex(v)
	st.generate_normals()
	return st.commit()

func _add_rock(parent: Node3D, mesh: ArrayMesh, pos: Vector3, yaw: float, mat: Material) -> void:
	var body: StaticBody3D = StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = pos
	body.rotation.y = yaw
	var mi: MeshInstance3D = MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	body.add_child(mi)
	var cs: CollisionShape3D = CollisionShape3D.new()
	cs.shape = mesh.create_trimesh_shape()    # ConcavePolygonShape3D: сквозь скалу пройти нельзя
	body.add_child(cs)
	parent.add_child(body)

## Гора с пещерой: монолитный скальный массив поверх конусов (Mass*) — уступы, карнизы, вершины;
## у каждой глыбы ConcavePolygonShape3D. Западный склон со входом в пещеру свободен.
func _build_mountain_massif() -> void:
	var root: Node3D = Node3D.new()
	root.name = "MountainMassif"
	add_child(root)
	var mat: StandardMaterial3D = _vertex_color_material(1.0, Color(1, 1, 1))
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 9091
	# [cx, cz, R, H, уровни высот]
	var cones: Array = [[85.0, 5.0, 30.0, 26.0, [1.5, 4.5, 8.0, 11.5, 15.0, 19.0]], [93.0, -5.0, 17.0, 34.0, [2.5, 7.0, 12.0, 18.0, 24.0]], [79.0, 19.0, 14.0, 20.0, [2.0, 5.5, 9.0, 13.0]]]
	var sid: int = 0
	for cn in cones:
		var cc: Array = cn
		var ctr: Vector2 = Vector2(float(cc[0]), float(cc[1]))
		var rad: float = float(cc[2])
		var hh: float = float(cc[3])
		var levels: Array = cc[4]
		for lv in levels:
			var h: float = float(lv)
			var r_at: float = rad * (1.0 - h / hh)
			var count: int = maxi(3, int(r_at * 0.45))
			for k in count:
				var a: float = TAU * float(k) / float(count) + rng.randf_range(-0.25, 0.25) + h * 0.35
				if cc[0] == 85.0 and absf(wrapf(a - PI, -PI, PI)) < 0.95:
					continue    # вход в пещеру
				if cc[0] == 79.0 and absf(wrapf(a - PI, -PI, PI)) < 0.8:
					continue
				var sz: float = rng.randf_range(3.2, 5.2)
				var mesh: ArrayMesh = _rock_mesh(float(sid) * 1.37, sz * 1.15, sz * 0.55, sz, rng.randf_range(0.45, 0.7), 0.5)
				sid += 1
				var pos: Vector3 = Vector3(ctr.x + cos(a) * (r_at - 0.8), h, ctr.y + sin(a) * (r_at - 0.8))
				_add_rock(root, mesh, pos, -a, mat)
		# вершина
		var crown: ArrayMesh = _rock_mesh(float(sid) * 2.1, rad * 0.2, hh * 0.09, rad * 0.2, 0.8, 0.0)
		sid += 1
		_add_rock(root, crown, Vector3(ctr.x, hh - 1.5, ctr.y), 0.0, mat)

## Остров ведьмы: замшелый риф в воде с торчащими корнями деревьев. Верх рифа — плоская площадка.
func _add_root_tube(st: SurfaceTool, p0: Vector3, p1: Vector3, p2: Vector3, r0: float, r1: float, col: Color) -> void:
	var segs: int = 8
	var sides: int = 6
	var rings: Array = []
	for i in range(segs + 1):
		var t: float = float(i) / float(segs)
		var pos: Vector3 = p0 * (1.0 - t) * (1.0 - t) + p1 * 2.0 * (1.0 - t) * t + p2 * t * t
		var tang: Vector3 = ((p1 - p0) * 2.0 * (1.0 - t) + (p2 - p1) * 2.0 * t).normalized()
		var up: Vector3 = Vector3.UP
		if absf(tang.y) > 0.9:
			up = Vector3.RIGHT
		var side: Vector3 = tang.cross(up).normalized()
		var up2: Vector3 = side.cross(tang).normalized()
		var radius: float = lerpf(r0, r1, t)
		var ring: Array = []
		for j in sides:
			var ang: float = TAU * float(j) / float(sides)
			ring.append(pos + (side * cos(ang) + up2 * sin(ang)) * radius)
		rings.append(ring)
	for i in segs:
		for j in sides:
			var j2: int = (j + 1) % sides
			var a: Vector3 = rings[i][j]
			var b: Vector3 = rings[i][j2]
			var c: Vector3 = rings[i + 1][j]
			var d: Vector3 = rings[i + 1][j2]
			for v in [a, c, b, b, c, d]:
				st.set_color(col)
				st.add_vertex(v)

func _build_witch_island() -> void:
	var swamp: Node3D = get_parent().get_node_or_null("Swamp") as Node3D
	if swamp == null:
		return
	# старый синий цилиндр-«шайба» удалён из сцены; на всякий случай гасим, если остался
	_hide_csg(swamp.get_node_or_null("Throne"))
	var water: CSGCylinder3D = swamp.get_node_or_null("Water") as CSGCylinder3D
	var water_top: float = -2.55
	var wx: float = SWAMP_CENTER.x
	var wz: float = SWAMP_CENTER.z
	if water != null:
		water_top = water.position.y + water.height * 0.5
		wx = water.position.x
		wz = water.position.z
	var top_y: float = water_top + 0.8
	var ry: float = 1.7
	var flat: float = 0.85
	var rock: ArrayMesh = _rock_mesh(4.2, 2.5, ry, 2.5, flat, 0.0)
	var root: Node3D = Node3D.new()
	root.name = "WitchIsland"
	root.position = Vector3(wx, 0.0, wz)
	add_child(root)
	var mat: StandardMaterial3D = _vertex_color_material(1.0, Color(1, 1, 1))
	_add_rock(root, rock, Vector3(0.0, top_y - ry * flat, 0.0), 0.0, mat)
	# корни: дугой выходят из рифа, уходят в воду
	var st: SurfaceTool = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_smooth_group(0)
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 311
	for k in 9:
		var a: float = TAU * float(k) / 9.0 + rng.randf_range(-0.2, 0.2)
		var dirv: Vector3 = Vector3(cos(a), 0.0, sin(a))
		var p0: Vector3 = dirv * 1.5 + Vector3(0.0, top_y - 0.55, 0.0)
		var p1: Vector3 = dirv * rng.randf_range(2.4, 3.0) + Vector3(0.0, water_top + rng.randf_range(0.7, 1.6), 0.0)
		var p2: Vector3 = dirv * rng.randf_range(3.2, 4.2) + Vector3(0.0, water_top - rng.randf_range(0.1, 0.7), 0.0)
		_add_root_tube(st, p0, p1, p2, rng.randf_range(0.15, 0.22), 0.05, Color(0.14, 0.09, 0.05))
	st.generate_normals()
	var rmi: MeshInstance3D = MeshInstance3D.new()
	rmi.name = "Roots"
	rmi.mesh = st.commit()
	rmi.material_override = _vertex_color_material(0.95, Color(1, 1, 1))
	root.add_child(rmi)
	islet_top_y = top_y

## Вход в пещеру: ступени, вырубленные в скале (0.25 x ~0.69 м — тот же уклон 20°), невидимый наклонный
## коллайдер по носикам и единый каменный портал (притолока параллельна своду тоннеля).
func _build_cave_entrance() -> void:
	var cave: Node3D = get_parent().get_node_or_null("Cave") as Node3D
	if cave == null:
		return
	for i in 14:
		_hide_csg(cave.get_node_or_null("Step%d" % i))    # старые тонкие декоративные плитки
	var body: StaticBody3D = StaticBody3D.new()
	body.name = "CaveStairs"
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	var mat_a: StandardMaterial3D = _stone_mat(Color(0.23, 0.23, 0.25))
	var mat_b: StandardMaterial3D = _stone_mat(Color(0.19, 0.2, 0.21))
	var tan20: float = tan(deg_to_rad(20.0))
	var run: float = STEP_RISE / tan20
	var z0: float = 5.0
	for i in CAVE_STEPS:
		var x_i: float = CAVE_STEP_X0 + run * float(i)
		var y_i: float = -STEP_RISE * float(i)
		_add_static_box(body, Transform3D(Basis.IDENTITY, Vector3(x_i + run * 0.5, y_i - 0.6, z0)), Vector3(run + 0.06, 1.2, 5.4), mat_a if i % 2 == 0 else mat_b)
	# наклонный коллайдер по линии носиков (x_1, 0) ... (x_end, ...)
	var x1: float = CAVE_STEP_X0 + run
	var x_end: float = CAVE_STEP_X0 + run * float(CAVE_STEPS)
	var y_end: float = -STEP_RISE * float(CAVE_STEPS - 1)
	var mid2: Vector2 = Vector2((x1 + x_end) * 0.5, y_end * 0.5)
	var length: float = Vector2(x_end - x1, y_end).length() + 0.3
	var up: Vector2 = Vector2(sin(deg_to_rad(20.0)), cos(deg_to_rad(20.0)))
	var rb: Basis = Basis(Vector3.BACK, deg_to_rad(-20.0))
	_add_static_box(body, Transform3D(rb, Vector3(mid2.x - up.x * 0.15, mid2.y - up.y * 0.15, z0)), Vector3(length, 0.3, 5.0), null, false)
	# портал: блоки в системе координат тоннеля (s вдоль пола, u вверх), z = 2.3..7.7
	var dir20: Vector2 = Vector2(cos(deg_to_rad(20.0)), -sin(deg_to_rad(20.0)))
	var s_p: float = -7.25
	var port_mat: StandardMaterial3D = _stone_mat(Color(0.21, 0.22, 0.23))
	var port_mat2: StandardMaterial3D = _stone_mat(Color(0.26, 0.26, 0.27))
	var base: Vector2 = CAVE_B + dir20 * s_p
	var pb: Basis = Basis(Vector3.BACK, deg_to_rad(-20.0))
	# притолока: верх вровень со сводом тоннеля (u = 5.0), низ на u = 3.6
	var lint_c: Vector2 = base + up * 4.3
	_add_static_box(body, Transform3D(pb, Vector3(lint_c.x, lint_c.y, 5.0)), Vector3(1.8, 1.4, 6.0), port_mat2)
	# косяки: от пола (чуть ниже ступеней) до притолоки, заходят в стены тоннеля
	var jamb_c: Vector2 = base + up * 1.55
	_add_static_box(body, Transform3D(pb, Vector3(jamb_c.x, jamb_c.y, 2.45)), Vector3(1.8, 4.5, 1.1), port_mat)
	_add_static_box(body, Transform3D(pb, Vector3(jamb_c.x, jamb_c.y, 7.55)), Vector3(1.8, 4.5, 1.1), port_mat)

# ================================================================== v12: скачанные 3D-модели
const HUT_FOOT: float = 10.8             # внешний размер стен избы, м (как у прежней коробки 10.4 + толщина)
const HUT_WALLS_AABB: AABB = AABB(Vector3(6.46, 10.47, 33.73), Vector3(4.18, 2.64, 4.37))    # меш стен в координатах модели
const HUT_WALL_H: float = 3.8            # высота стен: дверной проём ~2.6 м, притолока выше роста игрока
const HUT_WALL_NODES: Array = ["WallN", "WallW", "WallE", "WallSL", "WallSR", "Lintel", "Post0", "Post1", "Post2", "Post3", "RoofL", "RoofR", "Ridge", "GableN0", "GableN1", "GableN2", "GableN3", "GableS0", "GableS1", "GableS2", "GableS3"]
const MOUNTAIN_POS: Vector3 = Vector3(88.0, 0.0, 4.0)     # центр горы (прежние конусы Mass* — (85, 5))
const MOUNTAIN_SIZE: Vector3 = Vector3(62.0, 38.0, 62.0)  # габариты модели, м
const MOUNTAIN_BASE_Y: float = -1.0
const SEA_CAVE_POS: Vector3 = Vector3(57.0, 0.0, 5.0)     # портал на оси лестницы в пещеру
const SEA_CAVE_SCALE: float = 0.032                       # модель в «сканерных» единицах (~1000 ед. шириной)
const SEA_CAVE_YAW_DEG: float = 90.0
const SEA_CAVE_BASE_Y: float = -3.0
const CAVE_FLOOR_X0: float = 52.49                        # CAVE_STEP_X0 + STEP_RISE / tan(20°)
const CAVE_FLOOR_MIN_Y: float = -10.6                     # пол грота
const PINE_MAX: int = 380

func _v12_path(role: String) -> String:
	var arr: Array = catalog.get(role, [])
	if arr.is_empty():
		return ""
	return String(arr[0])

## AABB только тех мешей, чьё имя содержит filter (пусто = все), в координатах root.
func _named_aabb(root: Node3D, filter: String) -> AABB:
	var arr: Array = []
	ModelLib.collect_meshes(root, arr)
	var res: AABB = AABB()
	var first: bool = true
	for m in arr:
		var mi: MeshInstance3D = m
		if filter != "" and String(mi.name).to_lower().find(filter) == -1:
			continue
		var box: AABB = ModelLib.rel_xform(mi, root) * mi.get_aabb()
		if first:
			res = box
			first = false
		else:
			res = res.merge(box)
	return res

## Центр AABB по X/Z ставит в начало координат holder, низ — на base_y; масштаб по осям.
func _place_scaled(inst: Node3D, ab: AABB, sc: Vector3, base_y: float) -> void:
	var c: Vector3 = ab.get_center()
	inst.scale = sc
	inst.position = Vector3(-c.x * sc.x, base_y - ab.position.y * sc.y, -c.z * sc.z)

func _fit_size(inst: Node3D, ab: AABB, size: Vector3, base_y: float) -> void:
	_place_scaled(inst, ab, Vector3(size.x / maxf(ab.size.x, 0.0001), size.y / maxf(ab.size.y, 0.0001), size.z / maxf(ab.size.z, 0.0001)), base_y)

## Свободен ли ход по лестнице и тоннелю в грот: над полом (20°, z = 3..7) на рост игрока нет моделей с меткой v12_cave.
func _cave_floor_y(x: float) -> float:
	if x < CAVE_FLOOR_X0:
		return 0.0
	return maxf(-(x - CAVE_FLOOR_X0) * tan(deg_to_rad(20.0)), CAVE_FLOOR_MIN_Y)

func _v12_cave_hit(from: Vector3, to: Vector3) -> bool:
	var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(from, to)
	q.collision_mask = 1
	var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(q)
	if hit.is_empty():
		return false
	var col: Object = hit.get("collider")
	return col is Node and (col as Node).has_meta("v12_cave")

## Свободен ли ход по лестнице и тоннелю: над полом и по ходу движения (z = 2.6..7.4) нет моделей с меткой v12_cave.
func _cave_corridor_clear() -> bool:
	for xi in range(44, 106, 2):
		var x: float = float(xi)
		var fy: float = _cave_floor_y(x)
		var fy2: float = _cave_floor_y(x + 2.0)
		for zv in [2.6, 3.8, 5.0, 6.2, 7.4]:
			var z: float = zv
			if _v12_cave_hit(Vector3(x, fy + 0.05, z), Vector3(x, fy + 2.4, z)):
				return false
			for hh in [0.5, 1.2, 1.9]:
				var h: float = hh
				if _v12_cave_hit(Vector3(x, fy + h, z), Vector3(x + 2.0, fy2 + h, z)):
					return false
	return true

func _wait_physics(n: int) -> void:
	for i in n:
		await get_tree().physics_frame

# ------------------------------------------------------------------ изба: thatch_hut_base
func _hut_door_clear(base: Vector3) -> bool:
	var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	for xo in [-0.9, 0.0, 0.9]:
		for yo in [0.4, 1.2, 2.0]:
			var xf: float = xo
			var yf: float = yo
			var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(base + Vector3(xf, yf, 8.0), base + Vector3(xf, yf, 3.0))
			q.collision_mask = 1
			var hit: Dictionary = space.intersect_ray(q)
			if not hit.is_empty():
				var col: Object = hit.get("collider")
				if col is Node and (col as Node).has_meta("v12_hut"):
					return false
	return true

## Мебель и мелочи у стен сдвигаются внутрь контура стен (внутренний край ~ ±4.4 м).
func _pull_interior_inside(hut: Node3D) -> void:
	for c in hut.get_children():
		var n: Node3D = c as Node3D
		if n == null or String(n.name) in HUT_WALL_NODES or String(n.name) in ["Floor", "HutLight", "Rug"]:
			continue
		var hx: float = 0.0
		var hz: float = 0.0
		if n is CSGBox3D:
			hx = (n as CSGBox3D).size.x * 0.5
			hz = (n as CSGBox3D).size.z * 0.5
		elif n is CSGCylinder3D:
			hx = (n as CSGCylinder3D).radius
			hz = hx
		n.position.x = clampf(n.position.x, -4.3 + hx, 4.3 - hx)
		n.position.z = clampf(n.position.z, -4.3 + hz, 4.3 - hz)

func _build_hut_model() -> void:
	var path: String = _v12_path("thatch_hut")
	var hut: Node3D = get_parent().get_node_or_null("Hut") as Node3D
	if path == "" or hut == null:
		return
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	var holder: Node3D = Node3D.new()
	holder.name = "ThatchHut"
	holder.position = hut.global_position
	holder.rotation_degrees = Vector3(0.0, 180.0, 0.0)    # дверь модели (-Z) -> вход избы (+Z, x = 0)
	add_child(holder)
	holder.add_child(inst)
	var walls: AABB = HUT_WALLS_AABB
	var sxz: float = HUT_FOOT / maxf(maxf(walls.size.x, walls.size.z), 0.0001)
	var sy: float = HUT_WALL_H / maxf(walls.size.y, 0.0001)
	_place_scaled(inst, walls, Vector3(sxz, sy, sxz), -0.05)
	_pull_interior_inside(hut)
	# коллизия стен — по мешу стен (крыша без коллизии: свес низкий)
	var body: StaticBody3D = ModelLib.add_trimesh_body_v12(holder, inst, "walls", "v12_hut")
	for nm in HUT_WALL_NODES:
		var n: Node = hut.get_node_or_null(String(nm))
		if n == null:
			continue
		_hide_render(n)
		if n is CSGShape3D:
			(n as CSGShape3D).use_collision = false
	# проверка входа: пробуем обе ориентации модели; если проём закрыт — возвращаем невидимые стены
	var ok: bool = false
	for yaw in [180.0, 0.0]:
		holder.rotation_degrees = Vector3(0.0, float(yaw), 0.0)
		await _wait_physics(3)
		if _hut_door_clear(hut.global_position):
			ok = true
			break
	if not ok or body.get_child_count() == 0:
		holder.rotation_degrees = Vector3(0.0, 180.0, 0.0)
		body.queue_free()
		for nm2 in HUT_WALL_NODES:
			var n2: Node = hut.get_node_or_null(String(nm2))
			if n2 is CSGShape3D:
				(n2 as CSGShape3D).use_collision = true

# ------------------------------------------------------------------ гора: rock_mountain
func _darken_stone(root: Node3D) -> void:
	var arr: Array = []
	ModelLib.collect_meshes(root, arr)
	for m in arr:
		var mi: MeshInstance3D = m
		if mi.mesh == null:
			continue
		for s in mi.mesh.get_surface_count():
			var mat: Material = mi.get_active_material(s)
			var dm: StandardMaterial3D = null
			if mat is StandardMaterial3D:
				dm = (mat as StandardMaterial3D).duplicate() as StandardMaterial3D
			else:
				dm = StandardMaterial3D.new()
			dm.albedo_color = Color(0.5, 0.5, 0.55)
			dm.roughness = 1.0
			dm.metallic = 0.0
			dm.cull_mode = BaseMaterial3D.CULL_DISABLED
			mi.set_surface_override_material(s, dm)

func _build_big_mountain() -> void:
	var path: String = _v12_path("big_mountain")
	var inst: Node3D = ModelLib.instance(path) if path != "" else null
	if inst == null:
		return
	var holder: Node3D = Node3D.new()
	holder.name = "RockMountain"
	holder.position = Vector3(MOUNTAIN_POS.x, 0.0, MOUNTAIN_POS.z)
	add_child(holder)
	holder.add_child(inst)
	_fit_size(inst, ModelLib.mesh_aabb(inst), MOUNTAIN_SIZE, MOUNTAIN_BASE_Y)
	_darken_stone(inst)
	var body: StaticBody3D = ModelLib.add_trimesh_body_v12(holder, inst, "", "v12_cave")
	# Основание горы не должно перекрывать лестницу и тоннель: сдвигаем на восток, пока рост игрока свободно проходит
	var ok: bool = false
	for step in 18:
		holder.position.x = MOUNTAIN_POS.x + float(step)
		await _wait_physics(2)
		if _cave_corridor_clear():
			ok = true
			break
	if not ok:
		body.queue_free()

# ------------------------------------------------------------------ вход в пещеру: sea_cave_4
func _build_sea_cave() -> void:
	var path: String = _v12_path("sea_cave")
	var inst: Node3D = ModelLib.instance(path) if path != "" else null
	if inst == null:
		return
	var holder: Node3D = Node3D.new()
	holder.name = "SeaCaveMouth"
	holder.position = Vector3(SEA_CAVE_POS.x, SEA_CAVE_BASE_Y, SEA_CAVE_POS.z)
	holder.rotation_degrees = Vector3(0.0, SEA_CAVE_YAW_DEG, 0.0)
	add_child(holder)
	holder.add_child(inst)
	_place_scaled(inst, ModelLib.mesh_aabb(inst), Vector3(SEA_CAVE_SCALE, SEA_CAVE_SCALE, SEA_CAVE_SCALE), 0.0)
	var body: StaticBody3D = ModelLib.add_trimesh_body_v12(holder, inst, "", "v12_cave")
	# Высота свода: поднимаем портал шагами по 0.5 м, пока над ступенями не останется проход выше роста игрока
	var ok: bool = false
	for step in 25:
		holder.position.y = SEA_CAVE_BASE_Y + 0.5 * float(step)
		await _wait_physics(2)
		if _cave_corridor_clear():
			ok = true
			break
	if not ok:
		body.queue_free()    # только визуал: проход гарантированно свободен

# ------------------------------------------------------------------ башня: book_stand + red_book
const STAND_PLATE_LOCAL: Vector3 = Vector3(2.25, 4.6, 2.12)    # центр наклонной панели book_stand в координатах модели
const STAND_TILT_DEG: float = 34.0

func _build_book_props() -> void:
	var tower: Node3D = get_parent().get_node_or_null("BookTower") as Node3D
	if tower == null:
		return
	var ped: Node3D = tower.get_node_or_null("Pedestal") as Node3D
	var book: Node3D = tower.get_node_or_null("Book") as Node3D
	if ped == null or book == null:
		return
	var yaw: Basis = Basis(Vector3.UP, -PI * 0.5)    # панель обращена к входу (+Z)
	var tilt: Basis = Basis.IDENTITY
	var plate: Vector3 = Vector3(0.0, 1.0, 0.0)       # центр опоры книги в координатах стойки
	var hold_pos: Vector3 = Vector3(ped.position.x, 0.0, ped.position.z)
	var sp: String = _v12_path("book_stand")
	var si: Node3D = ModelLib.instance(sp) if sp != "" else null
	if si != null:
		var holder: Node3D = Node3D.new()
		holder.name = "BookStandModel"
		holder.position = hold_pos
		holder.basis = yaw
		tower.add_child(holder)
		holder.add_child(si)
		var ab: AABB = ModelLib.mesh_aabb(si)
		var s: float = 1.08 / maxf(ab.size.y, 0.0001)
		_place_scaled(si, ab, Vector3(s, s, s), 0.0)
		var c: Vector3 = ab.get_center()
		plate = Vector3((STAND_PLATE_LOCAL.x - c.x) * s, (STAND_PLATE_LOCAL.y - ab.position.y) * s, (STAND_PLATE_LOCAL.z - c.z) * s)
		tilt = Basis(Vector3(0.0, 0.0, 1.0), deg_to_rad(-STAND_TILT_DEG))
		_hide_render(ped)    # невидимый блок остаётся коллайдером
	var bp: String = _v12_path("red_book")
	var bi: Node3D = ModelLib.instance(bp) if bp != "" else null
	if bi == null:
		return
	for nm in ["Cover", "Pages", "Clasp"]:
		_hide_csg(book.get_node_or_null(String(nm)))
	book.add_child(bi)    # зона «Взять книгу рецептов» (StaticBody3D Book) не меняется
	var bab: AABB = ModelLib.mesh_aabb(bi)
	var bs: float = 0.5 / maxf(bab.size.z, 0.0001)
	var thick: float = bab.size.y * bs
	var target_local: Vector3 = plate + (tilt * Vector3.UP) * (thick * 0.5 + 0.005)
	var target_rel: Vector3 = hold_pos + yaw * target_local - book.position
	bi.basis = (yaw * tilt) * Basis.from_scale(Vector3(bs, bs, bs))
	bi.position = target_rel - bi.basis * bab.get_center()

# ------------------------------------------------------------------ тайник с ключом: валуны
func _build_key_boulders() -> void:
	var path: String = _v12_path("boulder")
	var cleft: Node3D = get_parent().get_node_or_null("Cleft") as Node3D
	if path == "" or cleft == null:
		return
	var root: Node3D = Node3D.new()
	root.name = "KeyBoulders"
	add_child(root)
	# [dx центра, y низа над землёй, dz, размер X, размер Y, размер Z, рыскание°]; внутренняя грань — на прежнем краю щели
	var piles: Dictionary = {
		"RockA": [[-0.2, -0.3, 0.0, 6.2, 6.0, 9.8, 0.0], [-0.4, 4.6, 0.3, 5.4, 5.6, 8.6, 180.0], [-0.7, 9.4, -0.2, 4.6, 5.0, 7.4, 8.0], [-1.0, 13.2, 0.0, 3.4, 3.8, 5.2, -10.0]],
		"RockB": [[0.2, -0.3, 0.0, 6.2, 6.0, 9.8, 180.0], [0.4, 4.4, -0.3, 5.4, 5.6, 8.6, 0.0], [0.7, 9.0, 0.2, 4.6, 5.0, 7.4, -8.0], [1.0, 12.6, 0.0, 3.4, 3.8, 5.2, 10.0]],
		"RockBack": [[0.0, -0.3, 0.0, 10.5, 11.0, 4.2, 0.0]]
	}
	for key in piles:
		var src: CSGBox3D = cleft.get_node_or_null(String(key)) as CSGBox3D
		if src == null:
			continue
		var ground: float = src.position.y - src.size.y * 0.5
		var list: Array = piles[key]
		for e in list:
			var d: Array = e
			var inst: Node3D = ModelLib.instance(path)
			if inst == null:
				continue
			var holder: Node3D = Node3D.new()
			holder.position = Vector3(src.position.x + float(d[0]), ground + float(d[1]), src.position.z + float(d[2]))
			holder.rotation_degrees = Vector3(0.0, float(d[6]), 0.0)
			holder.set_meta("pile", String(key))
			holder.set_meta("rel", float(d[1]))
			holder.set_meta("fw", float(d[3]))
			holder.set_meta("fd", float(d[5]))
			root.add_child(holder)
			holder.add_child(inst)
			_fit_size(inst, ModelLib.mesh_aabb(inst), Vector3(float(d[3]), float(d[4]), float(d[5])), 0.0)
			ModelLib.add_convex_body(holder, inst)
		_hide_csg(src)
	# камень тайника: интерактив KeyStone и блеск ключа остаются на месте, меняется только визуал
	var ks: Node3D = cleft.get_node_or_null("KeyStone") as Node3D
	if ks != null:
		var ki: Node3D = ModelLib.instance(path)
		if ki != null:
			_hide_csg(ks.get_node_or_null("Rock"))
			ks.add_child(ki)
			_fit_size(ki, ModelLib.mesh_aabb(ki), Vector3(1.5, 0.9, 1.3), -0.5)

# ------------------------------------------------------------------ дремучая хвойная чаща: pine_tree
func _baked_unit_mesh(inst: Node3D, ab: AABB, filter: String = "") -> ArrayMesh:
	var arr: Array = []
	ModelLib.collect_meshes(inst, arr)
	var out: ArrayMesh = ArrayMesh.new()
	var k: float = 1.0 / maxf(ab.size.y, 0.0001)
	var c: Vector3 = ab.get_center()
	var norm: Transform3D = Transform3D(Basis.from_scale(Vector3(k, k, k)), Vector3(-c.x * k, -ab.position.y * k, -c.z * k))
	for m in arr:
		var mi: MeshInstance3D = m
		if mi.mesh == null:
			continue
		if filter != "" and String(mi.name).to_lower().find(filter) == -1:
			continue
		var xf: Transform3D = norm * ModelLib.rel_xform(mi, inst)
		for s in mi.mesh.get_surface_count():
			var st: SurfaceTool = SurfaceTool.new()
			st.begin(Mesh.PRIMITIVE_TRIANGLES)
			st.append_from(mi.mesh, s, xf)
			st.commit(out)
			var mat: Material = mi.get_active_material(s)
			if mat is StandardMaterial3D:
				var dup: StandardMaterial3D = (mat as StandardMaterial3D).duplicate() as StandardMaterial3D
				dup.cull_mode = BaseMaterial3D.CULL_DISABLED
				mat = dup
			out.surface_set_material(out.get_surface_count() - 1, mat)
	return out

func _build_pines() -> void:
	var path: String = _v12_path("pine")
	var inst: Node3D = ModelLib.instance(path) if path != "" else null
	if inst == null:
		return
	var mesh: ArrayMesh = _baked_unit_mesh(inst, ModelLib.mesh_aabb(inst))
	inst.queue_free()
	if mesh == null or mesh.get_surface_count() == 0:
		return
	var samples: Array = []
	for trail in PathBuilder.TRAILS:
		var pts: Array = trail
		for k in range(pts.size() - 1):
			var a: Vector2 = Vector2(float(pts[k][0]), float(pts[k][2]))
			var b: Vector2 = Vector2(float(pts[k + 1][0]), float(pts[k + 1][2]))
			var steps: int = maxi(1, int(a.distance_to(b) / 2.5))
			for s in steps:
				samples.append(a.lerp(b, float(s) / float(steps)))
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 12012
	var spots: Array = []
	for i in samples.size():
		var base: Vector2 = samples[i]
		for side in [-1.0, 1.0]:
			var sd: float = side
			for rep in 2:
				if spots.size() >= PINE_MAX or rng.randf() < 0.2:
					continue
				var off: float = rng.randf_range(4.5, 17.0)
				var p: Vector2 = base + Vector2(sd * off + rng.randf_range(-1.5, 1.5), rng.randf_range(-3.0, 3.0))
				if _near_any(p, samples, 3.5) or p.length() < 12.0:
					continue
				if absf(p.x + 40.0) < 6.0 or p.distance_to(Vector2(-25.0, 34.0)) < 14.0 or p.distance_to(Vector2(-78.0, -24.0)) < 13.0:
					continue
				if p.x > 46.0 or absf(p.x) > 150.0 or absf(p.y) > 150.0:
					continue
				var gy: Variant = _ground_y(p.x, p.y, 40.0, -6.0)
				if gy == null:
					continue
				spots.append(Vector3(p.x, float(gy) - 0.12, p.y))
	if spots.is_empty():
		return
	var mm: MultiMesh = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = spots.size()
	var colliders: StaticBody3D = StaticBody3D.new()
	colliders.name = "PineColliders"
	for i in spots.size():
		var sp: Vector3 = spots[i]
		var h: float = rng.randf_range(6.5, 11.5)
		var w: float = h * rng.randf_range(0.85, 1.1)
		var b2: Basis = Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(w, h, w))
		mm.set_instance_transform(i, Transform3D(b2, sp))
		var cs: CollisionShape3D = CollisionShape3D.new()
		var cyl: CylinderShape3D = CylinderShape3D.new()
		cyl.radius = 0.35
		cyl.height = 3.0
		cs.shape = cyl
		cs.position = sp + Vector3(0.0, 1.5, 0.0)
		colliders.add_child(cs)
	var mmi: MultiMeshInstance3D = MultiMeshInstance3D.new()
	mmi.name = "PineThicket"
	mmi.multimesh = mm
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mmi.visibility_range_end = 150.0
	add_child(mmi)
	add_child(colliders)

## v13: одиночные плоскости/квады без опоры над оврагом, пещерой и тайником (кроме воды реки) удаляются.
func _purge_shards() -> void:
	for root_name in ["Ravine", "Cave", "Cleft"]:
		var r: Node = get_parent().get_node_or_null(root_name)
		if r == null:
			continue
		for n in r.find_children("*", "MeshInstance3D", true, false):
			var mi: MeshInstance3D = n as MeshInstance3D
			if String(mi.name) == "River" or mi.mesh == null:
				continue
			if mi.mesh is PlaneMesh or mi.mesh is QuadMesh:
				mi.queue_free()

# ================================================================== v15: модели из res://assets/custom/
const V14_DIR: String = "res://assets/custom/"
const V14_TABLES: String = "medieval_tables__chairs.glb"
const V14_PINE: String = "pine_tree_trio_-_free_download.glb"
const V14_WALL: String = "freshford_church_wall_extract.glb"
const V14_CRYSTALS: Array = ["stylized_crystal_cluster.glb", "low_poly_purple_crystal_cluster.glb"]
const V14_PINE_K: float = 0.9
const V14_PINE_TINT: Color = Color(0.62, 0.68, 0.74)

var pine_mats: Array = []

func _v14_instance(file: String) -> Node3D:
	var p: String = V14_DIR + file
	if not ResourceLoader.exists(p):
		push_warning("[v15] файл не найден или не импортирован: " + p)
		return null
	return ModelLib.instance(p)

## Оставляет в инстансе только группу group_name (остальные узлы-соседи удаляются сразу).
func _v14_only_group(inst: Node3D, group_name: String) -> bool:
	var g: Node = inst.find_child(group_name, true, false)
	if g == null:
		return false
	var par: Node = g.get_parent()
	for sib in par.get_children():
		if sib != g:
			par.remove_child(sib)
			sib.free()
	return true

## Одна сосна из «трио» -> единичный меш для MultiMesh (низ ствола в y = 0).
func _v14_pine_mesh() -> ArrayMesh:
	var inst: Node3D = _v14_instance(V14_PINE)
	if inst == null:
		return null
	var filt: String = "pine_tree_pinetree"
	var ab: AABB = _named_aabb(inst, filt)
	if ab.size.y < 0.0001:
		filt = ""
		ab = ModelLib.mesh_aabb(inst)
	var mesh: ArrayMesh = _baked_unit_mesh(inst, ab, filt)
	inst.free()
	if mesh == null or mesh.get_surface_count() == 0:
		return null
	for i in mesh.get_surface_count():
		var m: Material = mesh.surface_get_material(i)
		if m is StandardMaterial3D:
			(m as StandardMaterial3D).albedo_color = V14_PINE_TINT
			pine_mats.append(m)
	return mesh

## Мебель: низ модели строго на floor_pos (уровень пола), коллизия — коробка по габаритам.
func _v14_furniture(file: String, group: String, parent: Node3D, node_name: String, floor_pos: Vector3, target_h: float, yaw: float) -> bool:
	var inst: Node3D = _v14_instance(file)
	if inst == null:
		return false
	if not _v14_only_group(inst, group):
		inst.free()
		return false
	var ab: AABB = ModelLib.mesh_aabb(inst)
	if ab.size.y < 0.0001:
		inst.free()
		return false
	var s: float = target_h / ab.size.y
	var holder: Node3D = Node3D.new()
	holder.name = node_name
	holder.position = floor_pos
	holder.rotation.y = yaw
	parent.add_child(holder)
	holder.add_child(inst)
	_place_scaled(inst, ab, Vector3(s, s, s), 0.0)
	var body: StaticBody3D = StaticBody3D.new()
	body.name = "Body"
	holder.add_child(body)
	var cs: CollisionShape3D = CollisionShape3D.new()
	var bx: BoxShape3D = BoxShape3D.new()
	bx.size = Vector3(ab.size.x * s, target_h, ab.size.z * s)
	cs.shape = bx
	cs.position = Vector3(0.0, target_h * 0.5, 0.0)
	body.add_child(cs)
	return true

func _build_v14_hut() -> void:
	var hut: Node3D = get_parent().get_node_or_null("Hut") as Node3D
	if hut == null:
		return
	var table: CSGBox3D = hut.get_node_or_null("Table") as CSGBox3D
	var leg: CSGBox3D = hut.get_node_or_null("TableLeg0") as CSGBox3D
	if table != null and leg != null:
		var fy: float = leg.position.y - leg.size.y * 0.5    # низ ножек = пол
		if _v14_furniture(V14_TABLES, "table2", hut, "TableModel", Vector3(table.position.x, fy, table.position.z), V16_TABLE_H, PI * 0.5):
			_hide_csg(table)
			for i in 4:
				_hide_csg(hut.get_node_or_null("TableLeg%d" % i))
	for i in [1, 2]:
		var st: CSGCylinder3D = hut.get_node_or_null("Stool%d" % i) as CSGCylinder3D
		if st == null:
			continue
		var fy2: float = st.position.y - st.height * 0.5
		if _v14_furniture(V14_TABLES, "stool", hut, "StoolModel%d" % i, Vector3(st.position.x, fy2, st.position.z), 0.5, float(i) * 1.7):
			_hide_csg(st)
	_build_v16_interior(hut)

## Стена-завал: тот же StaticBody (interactable cave_wall, Shape, текст) — меняется только визуал.
func _build_v14_cave_wall() -> void:
	var wall: Node3D = get_parent().get_node_or_null("Cave/CaveWall") as Node3D
	if wall == null:
		return
	var inst: Node3D = _v14_instance(V14_WALL)
	if inst == null:
		return
	var ab: AABB = ModelLib.mesh_aabb(inst)
	if ab.size.y < 0.0001:
		inst.free()
		return
	var holder: Node3D = Node3D.new()
	holder.name = "WallModel"
	holder.rotation_degrees = Vector3(0.0, 90.0, 0.0)    # ширина модели -> вдоль Z тоннеля, толщина -> вдоль X
	wall.add_child(holder)
	holder.add_child(inst)
	_fit_size(inst, ab, Vector3(5.8, 6.4, 0.9), -3.2)    # низ = низ коллайдера (6.4 м, центр в узле)
	for nm in ["Rocks", "Boulder0", "Boulder1", "Crack"]:
		_hide_csg(wall.get_node_or_null(nm))

## Друзы вместо троек цилиндров; OmniLight3D (CrAL..CrEL, TnC0L..TnC2L) остаются нетронутыми.
func _build_v14_crystals() -> void:
	var cave: Node3D = get_parent().get_node_or_null("Cave") as Node3D
	if cave == null:
		return
	var keys: Array = ["CrA", "CrB", "CrC", "CrD", "CrE", "TnC0", "TnC1", "TnC2"]
	for ki in keys.size():
		var nodes: Array = []
		for i in 3:
			var n0: Node3D = cave.get_node_or_null("%s_%d" % [keys[ki], i]) as Node3D
			if n0 != null:
				nodes.append(n0)
		if nodes.is_empty():
			continue
		var c: Vector3 = Vector3.ZERO
		var hsum: float = 0.0
		var low: float = 1.0e9
		for n in nodes:
			var nd: Node3D = n
			var h: float = (nd as CSGCylinder3D).height if nd is CSGCylinder3D else 1.5
			c += nd.position
			hsum += h
			low = minf(low, nd.position.y - h * 0.5)
		c /= float(nodes.size())
		var target_h: float = clampf(hsum / float(nodes.size()), 0.8, 3.0)
		var base_y: float = low
		var wp: Vector3 = cave.to_global(c)
		var gy: Variant = _ground_y(wp.x, wp.z, wp.y + 1.5, wp.y - 5.0)
		if gy != null:
			base_y = cave.to_local(Vector3(wp.x, float(gy), wp.z)).y
		var inst: Node3D = _v14_instance(V14_CRYSTALS[ki % 2])
		if inst == null:
			continue
		var ab: AABB = ModelLib.mesh_aabb(inst)
		var s: float = target_h / maxf(ab.size.y, 0.0001)
		var holder: Node3D = Node3D.new()
		holder.name = "CrystalModel_%s" % keys[ki]
		holder.position = Vector3(c.x, base_y, c.z)
		holder.rotation.y = float(ki) * 1.1
		cave.add_child(holder)
		holder.add_child(inst)
		_place_scaled(inst, ab, Vector3(s, s, s), 0.0)
		for n2 in nodes:
			_hide_csg(n2)

# ================================================================== v16: расщелина с ключом
func _v16_ground(x: float, z: float, y_from: float, y_to: float, excl: Array[RID]) -> Variant:
	var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(Vector3(x, y_from, z), Vector3(x, y_to, z))
	q.collision_mask = 1
	q.exclude = excl
	q.hit_back_faces = false
	var hit: Dictionary = space.intersect_ray(q)
	if hit.is_empty():
		return null
	return (hit["position"] as Vector3).y

func _v16_fix_cleft() -> void:
	var cleft: Node3D = get_parent().get_node_or_null("Cleft") as Node3D
	if cleft == null:
		return
	# 1. висящие конусы/шпили (RockA/RockB уже заменены валунами и освобождены в _build_key_boulders)
	for nm in ["SpireA", "SpireB"]:
		_hide_csg(cleft.get_node_or_null(nm))
	var kb: Node3D = get_node_or_null("KeyBoulders") as Node3D
	var ks: Node3D = cleft.get_node_or_null("KeyStone") as Node3D
	if kb == null:
		return
	for nm2 in ["RockA", "RockB"]:
		_hide_csg(cleft.get_node_or_null(nm2))
	await _wait_physics(4)
	var excl: Array[RID] = []
	for b in kb.find_children("*", "StaticBody3D", true, false):
		excl.append((b as StaticBody3D).get_rid())
	if ks is StaticBody3D:
		excl.append((ks as StaticBody3D).get_rid())
	# 2. валуны на землю: каждая куча сдвигается целиком, нижний камень — на высоту террейна
	var piles: Dictionary = {}
	for h in kb.get_children():
		if h is Node3D and h.has_meta("pile"):
			var key: String = String(h.get_meta("pile"))
			if not piles.has(key):
				piles[key] = []
			(piles[key] as Array).append(h)
	for key2 in piles:
		var arr: Array = piles[key2]
		var bottom: Node3D = arr[0]
		for h2 in arr:
			if float((h2 as Node3D).get_meta("rel")) < float(bottom.get_meta("rel")):
				bottom = h2
		var bp: Vector3 = bottom.position
		var hw: float = float(bottom.get_meta("fw")) * 0.4
		var hd: float = float(bottom.get_meta("fd")) * 0.4
		var gmax: float = -1.0e9
		var found: bool = false
		for off in [Vector2.ZERO, Vector2(hw, hd), Vector2(-hw, hd), Vector2(hw, -hd), Vector2(-hw, -hd)]:
			var o: Vector2 = off
			var g: Variant = _v16_ground(bp.x + o.x, bp.z + o.y, bp.y + 10.0, bp.y - 30.0, excl)
			if g != null:
				gmax = maxf(gmax, float(g))
				found = true
		if not found:
			continue
		var delta: float = (gmax - 0.05) - bp.y
		for h3 in arr:
			(h3 as Node3D).position.y += delta
	# 3. материал: тёмно-серый камень #383838, roughness 0.95
	var rock: StandardMaterial3D = StandardMaterial3D.new()
	rock.albedo_color = Color("383838")
	rock.roughness = 0.95
	rock.metallic = 0.0
	for mi in kb.find_children("*", "MeshInstance3D", true, false):
		(mi as MeshInstance3D).material_override = rock
	if ks == null:
		return
	for mi2 in ks.find_children("*", "MeshInstance3D", true, false):
		(mi2 as MeshInstance3D).material_override = rock
	# 4. камень-тайник (и Glint ключа) строго между валунами, +0.15 м от земли
	var gk: Variant = _v16_ground(ks.global_position.x, ks.global_position.z, ks.global_position.y + 10.0, ks.global_position.y - 30.0, excl)
	if gk != null:
		var old_y: float = ks.global_position.y
		ks.global_position.y = float(gk) + 0.15
		for c in ks.get_children():
			if c is Node3D and not (c is CollisionShape3D) and not (c is CSGShape3D):
				(c as Node3D).position.y += 0.35    # низ модели камня (был -0.5 от центра) — на землю
		if absf(old_y - ks.global_position.y) > 0.0:
			pass

# ================================================================== v16: интерьер избушки
const V16_TABLE_H: float = 0.8
const V16_CHAIR_YAW: float = 40.0    # спинка стула -> -Z узла YagaRoot (за спиной Яги)

func _build_v16_interior(hut: Node3D) -> void:
	# стул Яги: старое кресло (YagaRoot/Chair) удалено из сцены; опора — стул из medieval_tables__chairs
	var yaga_root: Node3D = get_parent().get_node_or_null("YagaRoot") as Node3D
	if yaga_root != null and yaga_root.get_node_or_null("ChairModel") == null:
		var old: Node = yaga_root.get_node_or_null("Chair")
		if old != null:
			old.queue_free()
		_v14_furniture(V14_TABLES, "chair2", yaga_root, "ChairModel", Vector3(0.0, 0.0, -0.4), 1.1, V16_CHAIR_YAW)
	# колба — на столешницу модели стола: низ стекла = поверхность + 0.05
	var tm: Node3D = hut.get_node_or_null("TableModel") as Node3D
	var flask: Node3D = hut.get_node_or_null("Flask") as Node3D
	if tm != null and flask != null:
		var glass: CSGCylinder3D = flask.get_node_or_null("Glass") as CSGCylinder3D
		var gh: float = glass.height if glass != null else 0.34
		flask.position = Vector3(tm.position.x + 0.2, tm.position.y + V16_TABLE_H + 0.05 + gh * 0.5, tm.position.z - 0.1)
