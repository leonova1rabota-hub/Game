extends Node
## Глобальный синглтон: состояние квеста, инвентарь, сигналы.

signal inventory_changed
signal quest_updated(text: String)
signal dialogue_requested(title: String, text: String, choices: Array)
signal minigame_requested(type: String)
signal minigame_finished(type: String, success: bool)
signal focus_changed(target: Node)
signal interacted(object_id: String, node: Node)
signal message_requested(text: String)
signal sfx_requested(sfx_name: String)

const MAX_SLOTS: int = 4

var current_stage: int = 0
var inventory: Array[String] = []
var selected_slot: int = 0
var quest_text: String = ""
var task_active: bool = false
var book_found: bool = false
var modal_open: bool = false
var cutscene: bool = false
var move_vec: Vector2 = Vector2.ZERO
var jump_requested: bool = false
var look_delta: Vector2 = Vector2.ZERO
var focus_target: Node = null

var item_info: Dictionary = {
    "Ржавый топор": "Старый, но ещё годный, чтобы свалить сухое дерево.",
    "Старый ключ": "Тяжёлый ключ с совиной головкой. Откроет сундук на башне.",
    "Крыло ночной совы": "Мягкое чёрное крыло. Первый ингредиент зелья.",
    "Цветок Хаоса": "Окаменевший цветок, мерцающий всеми цветами. Второй ингредиент.",
    "Пустой хрустальный флакон": "Флакон из горного хрусталя. Для чьих-то слёз.",
    "Слёзы морской ведьмы": "Лунный жемчуг в жидком виде. Третий ингредиент.",
    "Сухой факел": "Просмоленный факел. Его надо зажечь от очага.",
    "Горящий факел": "Факел горит ровным пламенем. Неси его к жаровням.",
    "Перо Феникса": "Золотое перо, тёплое на ощупь. Последний ингредиент.",
    "Тяжёлый молот": "Тяжёлый кузнечный молот Бабы Яги. Разобьёт завал в пещере."
}

var book_text: String = (
    "КНИГА РЕЦЕПТОВ ЗЕЛЬЯ МОЛОДОСТИ\n\n" +
    "I. КРЫЛО НОЧНОЙ СОВЫ.\nСова вьёт гнездо на вершине башни на высоком холме за оврагом, на западе. Через овраг переберёшься по сухому дереву, если срубишь его ржавым топором из сарая. Ключ от совиного сундука спрятан в расщелине скал на юго-западе.\n\n" +
    "II. ЦВЕТОК ХАОСА.\nОкаменел в глубокой пещере, что прячется в горе на востоке. Спустись по каменным ступеням. Руны там слушаются лишь тому, кто разгадает: «Лишь тот сорвёт Цветок Хаоса, кто повторит вечный круг мира: Сначала выстави ту, что правит холодной ночью (Луна), затем ту стихию, что согреет в стужу и сожжёт спесь (Пламя), а венчает путь свет, что указывает дорогу путникам во тьме (Звезда).»\n\n" +
    "III. СЛЁЗЫ МОРСКОЙ ВЕДЬМЫ.\nГлухая болотная низина на юге. Ведьма горда и вспыльчива, но тоскует по жемчужине, потерянной в шторм. Грубость её ожесточит, добрая память растопит. Слёзы собирай в пустой хрустальный флакон.\n\n" +
    "IV. ПЕРО ФЕНИКСА.\nОгненный алтарь на высоком холме к северу. Зажги факел от очага под котлом. Порядок огней высечен на камне у алтаря, а смысл его — в загадке: «Древний Феникс требует верного пламени: зажги ту жаровню, с которой восходит утро (I); затем пройди мимо срединной и затепли вечерний закат (III); и лишь в конце разожги полуденное сердце алтаря (II).»\n\n" +
    "Каждое чудо бросай в котёл и удерживай жар в зелёной зоне."
)

func reset() -> void:
    current_stage = 0
    inventory.clear()
    selected_slot = 0
    quest_text = ""
    task_active = false
    book_found = false
    modal_open = false
    cutscene = false
    move_vec = Vector2.ZERO
    jump_requested = false
    look_delta = Vector2.ZERO
    focus_target = null
    inventory_changed.emit()

func input_locked() -> bool:
    return modal_open or cutscene

func has_item(item: String) -> bool:
    return inventory.has(item)

func add_item(item: String) -> bool:
    if inventory.size() >= MAX_SLOTS:
        message_requested.emit("Инвентарь полон! Сначала используй что-нибудь из вещей.")
        return false
    inventory.append(item)
    inventory_changed.emit()
    return true

func remove_item(item: String) -> void:
    var i: int = inventory.find(item)
    if i >= 0:
        inventory.remove_at(i)
        selected_slot = clampi(selected_slot, 0, MAX_SLOTS - 1)
        inventory_changed.emit()

func set_book_found() -> void:
    book_found = true
    inventory_changed.emit()

func set_quest(text: String) -> void:
    quest_text = text
    quest_updated.emit(text)

func show_message(text: String) -> void:
    message_requested.emit(text)

func play_sfx(sfx_name: String) -> void:
    sfx_requested.emit(sfx_name)

func show_dialogue(title: String, text: String, choices: Array = []) -> void:
    dialogue_requested.emit(title, text, choices)

func show_book() -> void:
    dialogue_requested.emit("Книга Рецептов", book_text, [])

func try_interact() -> void:
    if input_locked():
        return
    if focus_target != null and is_instance_valid(focus_target) and focus_target.has_method("interact"):
        focus_target.interact()
