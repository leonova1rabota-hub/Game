extends MeshInstance3D
## Река на дне оврага (Y = -6.0): тёмно-бирюзовая вода #0E2838, roughness 0.1, specular 0.5,
## быстрое течение через сдвиг UV.y += TIME * flow_speed (см. river_water.gdshader).

const SHADER_PATH: String = "res://assets/river_water.gdshader"

func _ready() -> void:
	if not ResourceLoader.exists(SHADER_PATH):
		return
	var m: ShaderMaterial = ShaderMaterial.new()
	m.shader = load(SHADER_PATH) as Shader
	m.set_shader_parameter("mode", 0)
	m.set_shader_parameter("water_color", Color(0.0549, 0.1569, 0.2196, 0.86))   # #0E2838
	m.set_shader_parameter("roughness_amount", 0.1)
	m.set_shader_parameter("specular_amount", 0.5)
	m.set_shader_parameter("flow_speed", 1.6)
	m.set_shader_parameter("river_center_x", global_position.x)
	m.set_shader_parameter("river_half_width", 3.1)
	m.set_shader_parameter("shore_width", 0.6)
	material_override = m
