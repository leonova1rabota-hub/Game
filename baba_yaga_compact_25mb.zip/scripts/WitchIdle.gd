extends Node3D
## Живое «дыхание» и мягкое покачивание корпуса болотной ведьмы (Tween, TRANS_SINE, loop).
## Узел стоит ногами на верхней грани постамента; по Y не смещается.

func _ready() -> void:
	# дыхание: лёгкое растяжение по высоте
	var br: Tween = create_tween().set_loops()
	br.tween_property(self, "scale", Vector3(0.992, 1.018, 0.992), 1.7).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	br.tween_property(self, "scale", Vector3(1.0, 1.0, 1.0), 1.7).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	# покачивание корпуса вокруг ног
	var sw: Tween = create_tween().set_loops()
	sw.tween_property(self, "rotation_degrees:z", 1.6, 2.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	sw.tween_property(self, "rotation_degrees:z", -1.6, 2.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var sx: Tween = create_tween().set_loops()
	sx.tween_property(self, "rotation_degrees:x", 1.0, 3.1).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	sx.tween_property(self, "rotation_degrees:x", -1.0, 3.1).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
