extends Node
## Хоррор-атмосфера: ночное небо #0B0E14, густой туман, свечение, виньетка.
## Volumetric Fog работает только в Forward+; в Compatibility/Mobile
## включается обычный густой туман (объёмный включается автоматически, если доступен).

const NIGHT: Color = Color("080B12")
const SKY_SHADER: String = "res://assets/sky_night.gdshader"
const SKY_TEX: String = "res://assets/custom/sky_swamp.jpg"
const VIGNETTE_SHADER: String = "res://assets/vignette.gdshader"

var env: Environment = null
var sky_mat: ShaderMaterial = null
var vignette_rect: ColorRect = null

func _ready() -> void:
	add_to_group("world_finale")
	var we: WorldEnvironment = get_parent().get_node_or_null("WorldEnvironment") as WorldEnvironment
	if we != null and we.environment != null:
		env = we.environment
		_setup_environment()
	_setup_vignette()

func _setup_environment() -> void:
	# --- небо
	if ResourceLoader.exists(SKY_SHADER):
		var sh: Shader = load(SKY_SHADER) as Shader
		if sh != null:
			sky_mat = ShaderMaterial.new()
			sky_mat.shader = sh
			if ResourceLoader.exists(SKY_TEX):
				var tex: Texture2D = load(SKY_TEX) as Texture2D
				if tex != null:
					sky_mat.set_shader_parameter("swamp_tex", tex)
			sky_mat.set_shader_parameter("night_color", Color("080B12"))
			sky_mat.set_shader_parameter("horizon_color", Color(0.045, 0.05, 0.13))
			var sky: Sky = Sky.new()
			sky.sky_material = sky_mat
			sky.radiance_size = Sky.RADIANCE_SIZE_64
			env.sky = sky
			env.background_mode = Environment.BG_SKY
	if sky_mat == null:
		env.background_mode = Environment.BG_COLOR
		env.background_color = NIGHT
	# --- свет: глубокий сине-фиолетовый
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.13, 0.14, 0.30)
	env.ambient_light_energy = 1.0
	# --- густой туман
	env.fog_enabled = true
	env.fog_light_color = Color("070A10")
	env.fog_sky_affect = 1.0
	env.fog_density = 0.035
	if RenderingServer.get_current_rendering_method() == "forward_plus":
		env.volumetric_fog_enabled = true
		env.volumetric_fog_density = 0.035
		env.fog_height = 1.5
		env.fog_height_density = 0.12
		env.volumetric_fog_albedo = Color(0.35, 0.33, 0.6)
		env.volumetric_fog_emission = Color(0.02, 0.02, 0.05)
		env.volumetric_fog_length = 90.0
	# --- сильное свечение (зелье, свечи, руны)
	env.glow_enabled = true
	env.glow_intensity = 1.0
	env.glow_strength = 1.15
	env.glow_bloom = 0.12
	env.glow_hdr_threshold = 1.1
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	# --- тон
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.12
	env.adjustment_saturation = 1.05

func _setup_vignette() -> void:
	if not ResourceLoader.exists(VIGNETTE_SHADER):
		return
	var layer: CanvasLayer = CanvasLayer.new()
	layer.name = "HorrorVignette"
	layer.layer = 0
	add_child(layer)
	vignette_rect = ColorRect.new()
	vignette_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	vignette_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var m: ShaderMaterial = ShaderMaterial.new()
	m.shader = load(VIGNETTE_SHADER) as Shader
	vignette_rect.material = m
	layer.add_child(vignette_rect)

## Вызывается WorldController в финале (группа world_finale).
func on_finale(duration: float) -> void:
	if sky_mat != null:
		var tw: Tween = create_tween()
		tw.tween_method(_set_day, 0.0, 1.0, duration)
	if env != null:
		var tg: Tween = create_tween().set_parallel(true)
		tg.tween_property(env, "glow_intensity", 0.5, duration)
		tg.tween_property(env, "adjustment_saturation", 1.2, duration)
	if vignette_rect != null and vignette_rect.material is ShaderMaterial:
		var mat: ShaderMaterial = vignette_rect.material as ShaderMaterial
		var tv: Tween = create_tween()
		tv.tween_method(func(v: float) -> void: mat.set_shader_parameter("strength", v), 0.85, 0.25, duration)

func _set_day(v: float) -> void:
	if sky_mat != null:
		sky_mat.set_shader_parameter("day", v)
