extends Area3D
## «WaterDeathZone»: игрок упал в бурную воду на дне оврага.
## Мягкий респавн: затемнение 0.4 с -> телепорт на берег перед пнем -> осветление 0.4 с.
## Сцена НЕ перезагружается, GameManager.reset() НЕ вызывается: инвентарь и квест сохраняются.

const RESPAWN_TEXT: String = "Течение вынесло тебя обратно на берег!"
const FADE_TIME: float = 0.4
const RESPAWN_XZ: Vector2 = Vector2(-32.5, 0.0)   # восточный берег, перед пнем DryStump (x = -35.5)
const RESPAWN_FALLBACK_Y: float = 0.6
const RESPAWN_YAW: float = PI * 0.5                # лицом к оврагу (на -X)

var triggered: bool = false
var fade_layer: CanvasLayer
var fade_rect: ColorRect

func _ready() -> void:
	monitoring = true
	body_entered.connect(_on_body_entered)
	fade_layer = CanvasLayer.new()
	fade_layer.layer = 95
	add_child(fade_layer)
	fade_rect = ColorRect.new()
	fade_rect.color = Color(0.0, 0.0, 0.0, 0.0)
	fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fade_layer.add_child(fade_rect)
	fade_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _on_body_entered(body: Node3D) -> void:
	if triggered or not body.is_in_group("player"):
		return
	triggered = true
	GameManager.cutscene = true            # блокирует управление Player (input_locked)
	GameManager.move_vec = Vector2.ZERO
	if body is CharacterBody3D:
		(body as CharacterBody3D).velocity = Vector3.ZERO
	GameManager.show_message(RESPAWN_TEXT)
	var tw_out: Tween = create_tween()
	tw_out.tween_property(fade_rect, "color:a", 1.0, FADE_TIME)
	await tw_out.finished
	if is_instance_valid(body):
		_teleport_to_bank(body)
	await get_tree().physics_frame
	var tw_in: Tween = create_tween()
	tw_in.tween_property(fade_rect, "color:a", 0.0, FADE_TIME)
	await tw_in.finished
	GameManager.cutscene = false
	triggered = false

func _teleport_to_bank(body: Node3D) -> void:
	var y: float = RESPAWN_FALLBACK_Y
	var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(
		Vector3(RESPAWN_XZ.x, 4.0, RESPAWN_XZ.y), Vector3(RESPAWN_XZ.x, -3.0, RESPAWN_XZ.y), 1)
	var hit: Dictionary = space.intersect_ray(q)
	if not hit.is_empty():
		y = (hit["position"] as Vector3).y + 0.3
	var pos: Vector3 = Vector3(RESPAWN_XZ.x, y, RESPAWN_XZ.y)
	body.global_position = pos
	body.rotation.y = RESPAWN_YAW
	if body is CharacterBody3D:
		(body as CharacterBody3D).velocity = Vector3.ZERO
	body.set("pitch", 0.0)
	body.set("safe_pos", pos)
	body.set("safe_timer", 0.0)
	var head: Node3D = body.get_node_or_null("Head") as Node3D
	if head != null:
		head.rotation.x = 0.0
