extends Node3D
## Живность ночного леса: вороны на сухих деревьях (низкополигональные силуэты
## с редким взмахом крыльев) и стаи летучих мышей (GPUParticles3D с шейдером траектории)
## вокруг башни и над болотом.

const Flags = preload("res://scripts/FeatureFlags.gd")
const BAT_PROCESS: String = "res://assets/bat_flight.gdshader"
const BAT_DRAW: String = "res://assets/bat_draw.gdshader"
const BAT_TEX: String = "res://assets/fx/bat_silhouette.png"

const TOWER_CENTER: Vector3 = Vector3(-78.0, 22.0, -24.0)
const SWAMP_CENTER: Vector3 = Vector3(-25.0, 5.5, 34.0)

var crow_mat: StandardMaterial3D = null

func _ready() -> void:
	crow_mat = StandardMaterial3D.new()
	crow_mat.albedo_color = Color(0.015, 0.015, 0.02)
	crow_mat.roughness = 0.85
	# ждём, пока ModelIntegrator посадит сухие деревья на рельеф
	for i in 8:
		await get_tree().physics_frame
	if Flags.CROWS:
		_spawn_crows()
	if Flags.BATS:
		_spawn_bats(TOWER_CENTER, 9, 6.0, 11.0, 4.0, 0.5, "BatsTower")
		_spawn_bats(SWAMP_CENTER, 7, 5.0, 13.0, 2.0, 0.6, "BatsSwamp")

# ------------------------------------------------------------------ вороны
func _spawn_crows() -> void:
	var swamp: Node = get_parent().get_node_or_null("Swamp")
	if swamp == null:
		return
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 1313
	var count: int = 0
	for c in swamp.get_children():
		var nm: String = String(c.name)
		if not (c is CSGCylinder3D) or not nm.begins_with("Dead") or nm.begins_with("DeadBranch"):
			continue
		if count >= 7:
			break
		var trunk: CSGCylinder3D = c as CSGCylinder3D
		var top: Vector3 = Vector3(trunk.position.x, trunk.position.y + trunk.height * 0.5 + 0.06, trunk.position.z)
		var crow: Node3D = _make_crow(rng)
		crow.position = top + Vector3(rng.randf_range(-0.1, 0.1), 0.0, rng.randf_range(-0.1, 0.1))
		crow.rotation.y = rng.randf() * TAU
		swamp.add_child(crow)
		count += 1

func _mesh_part(parent: Node3D, mesh: Mesh, pos: Vector3, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi: MeshInstance3D = MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = crow_mat
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi

func _make_crow(rng: RandomNumberGenerator) -> Node3D:
	var crow: Node3D = Node3D.new()
	crow.name = "Crow"
	var body: SphereMesh = SphereMesh.new()
	body.radius = 0.12
	body.height = 0.24
	body.radial_segments = 8
	body.rings = 4
	var bi: MeshInstance3D = _mesh_part(crow, body, Vector3(0.0, 0.14, 0.0))
	bi.scale = Vector3(0.85, 0.8, 1.9)
	var head: SphereMesh = SphereMesh.new()
	head.radius = 0.07
	head.height = 0.14
	head.radial_segments = 8
	head.rings = 4
	_mesh_part(crow, head, Vector3(0.0, 0.25, 0.2))
	var beak: CylinderMesh = CylinderMesh.new()
	beak.top_radius = 0.0
	beak.bottom_radius = 0.025
	beak.height = 0.11
	beak.radial_segments = 6
	_mesh_part(crow, beak, Vector3(0.0, 0.24, 0.31), Vector3(90.0, 0.0, 0.0))
	var tail: BoxMesh = BoxMesh.new()
	tail.size = Vector3(0.12, 0.015, 0.24)
	_mesh_part(crow, tail, Vector3(0.0, 0.12, -0.32), Vector3(-15.0, 0.0, 0.0))
	var wing: BoxMesh = BoxMesh.new()
	wing.size = Vector3(0.34, 0.012, 0.2)
	var wr: Node3D = Node3D.new()
	wr.position = Vector3(0.1, 0.2, 0.0)
	wr.rotation_degrees.z = -75.0
	crow.add_child(wr)
	_mesh_part(wr, wing, Vector3(0.17, 0.0, 0.0))
	var wl: Node3D = Node3D.new()
	wl.position = Vector3(-0.1, 0.2, 0.0)
	wl.rotation_degrees.z = 75.0
	crow.add_child(wl)
	_mesh_part(wl, wing, Vector3(-0.17, 0.0, 0.0))
	# редкий взмах крыльев: пауза 4–10 с, затем три быстрых взмаха
	var tw: Tween = create_tween().set_loops()
	tw.tween_interval(rng.randf_range(4.0, 10.0))
	for k in 3:
		tw.tween_property(wr, "rotation_degrees:z", 30.0, 0.1)
		tw.parallel().tween_property(wl, "rotation_degrees:z", -30.0, 0.1)
		tw.tween_property(wr, "rotation_degrees:z", -10.0, 0.1)
		tw.parallel().tween_property(wl, "rotation_degrees:z", 10.0, 0.1)
	tw.tween_property(wr, "rotation_degrees:z", -75.0, 0.25)
	tw.parallel().tween_property(wl, "rotation_degrees:z", 75.0, 0.25)
	return crow

# ------------------------------------------------------------------ летучие мыши
func _spawn_bats(center: Vector3, amount: int, r_min: float, r_max: float, h_var: float, spd: float, node_name: String) -> void:
	if not ResourceLoader.exists(BAT_PROCESS) or not ResourceLoader.exists(BAT_DRAW):
		return
	var p: GPUParticles3D = GPUParticles3D.new()
	p.name = node_name
	p.position = Vector3(center.x, 0.0, center.z)
	p.amount = amount
	p.lifetime = 1000.0
	p.explosiveness = 1.0
	p.local_coords = true
	p.fixed_fps = 0
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	p.visibility_aabb = AABB(Vector3(-r_max - 4.0, -4.0, -r_max - 4.0), Vector3((r_max + 4.0) * 2.0, 60.0, (r_max + 4.0) * 2.0))
	var pm: ShaderMaterial = ShaderMaterial.new()
	pm.shader = load(BAT_PROCESS) as Shader
	pm.set_shader_parameter("radius_min", r_min)
	pm.set_shader_parameter("radius_max", r_max)
	pm.set_shader_parameter("height", center.y)
	pm.set_shader_parameter("height_var", h_var)
	pm.set_shader_parameter("speed", spd)
	p.process_material = pm
	var q: QuadMesh = QuadMesh.new()
	q.size = Vector2(1.0, 0.5)
	var dm: ShaderMaterial = ShaderMaterial.new()
	dm.shader = load(BAT_DRAW) as Shader
	if ResourceLoader.exists(BAT_TEX):
		dm.set_shader_parameter("bat_tex", load(BAT_TEX) as Texture2D)
	q.material = dm
	p.draw_pass_1 = q
	p.emitting = true
	add_child(p)
