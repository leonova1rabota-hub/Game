extends StaticBody3D
## Универсальный интерактивный объект (группа "interactable").
## Слои: 1 = мир, 2 = игрок, 3 (значение 4) = интерактивные объекты.

@export var object_id: String = ""
@export var prompt_text: String = "Использовать"
@export var enabled: bool = true
@export var solid: bool = false

func _ready() -> void:
    set_enabled(enabled)

func set_enabled(value: bool) -> void:
    enabled = value
    if value:
        add_to_group("interactable")
        collision_layer = 5 if solid else 4
    else:
        remove_from_group("interactable")
        collision_layer = 1 if solid else 0
    collision_mask = 0

func interact() -> void:
    if not enabled:
        return
    GameManager.interacted.emit(object_id, self)
